import pygame as pg
from os import path

# jeu
FENETRE_LONGUEUR = 1080
FENETRE_LARGEUR = 680
TITRE = "The Prophecy Of Ulyce II"

# personnages
WALL_LAYER = 1
PLAYER_LAYER = 2
BULLET_LAYER = 3
MOB_LAYER = 2
EFFECTS_LAYER = 4
PLAYER_HITBOX = pg.Rect(0, 0, 64, 64)  # ??

# SKIN_GUERRIER_0 =

IMG_INVENTAIRE = None
