#
#               THE PROPHECY OF ULYCE II
#
#        Julien Goetghebeur (Alex Roho -> site internet: BreizhStudio.github.io, Evan Guyomarch -> map tiled)
#                       NSI 2021
#
#
# TODO :
#   - grille
#   - barre de vie mob !!!
#   - nettoyer code
#   - fin niveaux
#

#import os
#os.chdir('D:/Documents/NSI/The_Prophecy_Of_Ulyce_II/TPOU2_v4')
#os.chdir('/Users/juliengoetghebeur/Desktop/programmation/NSI/Projets/The_Prophecy_Of_Ulyce_II/TPOU2_v4')
import pygame as pg
from os import path
from constantes import *
from map import *
from personnages import *
from ennemies import *
from items import *
import sys


class Jeu:
    def __init__(self):
        pg.init()
        self.ecran = pg.display.set_mode((FENETRE_LONGUEUR, FENETRE_LARGEUR))
        pg.display.set_caption(TITRE)
        # self.clock = pg.time.Clock()
        self.load_data()

    def load_data(self):
        dossier_jeu = path.dirname(path.abspath("__file__"))  # path.dirname(__file__)
        self.dossier_img = path.join(dossier_jeu, 'img')
        self.dossier_sons = path.join(dossier_jeu, 'sons')
        self.dossier_music = path.join(dossier_jeu, 'music')
        self.dossier_font = path.join(dossier_jeu, 'font')
        self.dossier_maps = path.join(dossier_jeu, 'maps')
        self.dossier_maps = path.join(self.dossier_maps, 'level_1v2')

        self.font_ecriture = path.join(self.dossier_font, 'Retro Gaming.ttf')

        self.img_inventaire_fond = pg.image.load(path.join(self.dossier_img, 'inventaire_fond.png')).convert_alpha()
        self.img_inv_cache_case = pg.image.load(path.join(self.dossier_img, 'inventaire_cache_case.png')).convert_alpha()
        self.img_inv_case_select = pg.image.load(path.join(self.dossier_img, 'inventaire_case_select.png')).convert_alpha()
        self.img_inv_plus = pg.image.load(path.join(self.dossier_img, 'inventaire_plus.png')).convert_alpha()
        self.img_inv_vie_1 = pg.image.load(path.join(self.dossier_img, 'vie_1.png')).convert_alpha()
        self.img_inv_vie_2 = pg.image.load(path.join(self.dossier_img, 'vie_2.png')).convert_alpha()
        self.img_inv_vie_3 = pg.image.load(path.join(self.dossier_img, 'vie_3.png')).convert_alpha()
        self.img_inv_xp_1 = pg.image.load(path.join(self.dossier_img, 'xp_1.png')).convert_alpha()
        self.img_inv_xp_2 = pg.image.load(path.join(self.dossier_img, 'xp_2.png')).convert_alpha()
        self.img_inv_xp_3 = pg.image.load(path.join(self.dossier_img, 'xp_3.png')).convert_alpha()
        self.img_inv_degat_1 = pg.image.load(path.join(self.dossier_img, 'degat_1.png')).convert_alpha()
        self.img_inv_degat_2 = pg.image.load(path.join(self.dossier_img, 'degat_2.png')).convert_alpha()
        self.img_inv_degat_3 = pg.image.load(path.join(self.dossier_img, 'degat_3.png')).convert_alpha()
        self.img_inv_mana_1 = pg.image.load(path.join(self.dossier_img, 'mana_1.png')).convert_alpha()
        self.img_inv_mana_2= pg.image.load(path.join(self.dossier_img, 'mana_2.png')).convert_alpha()
        self.img_inv_mana_3 = pg.image.load(path.join(self.dossier_img, 'mana_3.png')).convert_alpha()
        self.img_inv_fleche_1 = pg.image.load(path.join(self.dossier_img, 'fleche_1.png')).convert_alpha()
        self.img_inv_fleche_2 = pg.image.load(path.join(self.dossier_img, 'fleche_2.png')).convert_alpha()
        self.img_inv_fleche_3 = pg.image.load(path.join(self.dossier_img, 'fleche_3.png')).convert_alpha()
        self.img_inv_logo_vie = pg.image.load(path.join(self.dossier_img, 'logo_vie.png')).convert_alpha()
        self.img_inv_logo_vitesse = pg.image.load(path.join(self.dossier_img, 'logo_vitesse.png')).convert_alpha()
        self.img_inv_logo_degat = pg.image.load(path.join(self.dossier_img, 'logo_degat.png')).convert_alpha()
        self.img_inv_logo_foudre = pg.image.load(path.join(self.dossier_img, 'logo_foudre.png')).convert_alpha()
        self.img_inv_logo_feu = pg.image.load(path.join(self.dossier_img, 'logo_feu.png')).convert_alpha()
        self.img_inv_logo_glace = pg.image.load(path.join(self.dossier_img, 'logo_glace.png')).convert_alpha()

        self.img_potion_vie = pg.image.load(path.join(self.dossier_img, 'potion_vie.png')).convert_alpha()
        self.img_potion_vie = pg.transform.scale(self.img_potion_vie, (48, 48))
        self.img_potion_vitesse = pg.image.load(path.join(self.dossier_img, 'potion_vitesse.png')).convert_alpha()
        self.img_potion_vitesse = pg.transform.scale(self.img_potion_vitesse, (48, 48))
        self.img_potion_degat = pg.image.load(path.join(self.dossier_img, 'potion_degat.png')).convert_alpha()
        self.img_potion_degat = pg.transform.scale(self.img_potion_degat, (48, 48))

        self.img_cle = pg.image.load(path.join(self.dossier_img, 'cle.png')).convert_alpha()
        self.img_cle = pg.transform.scale(self.img_cle, (48, 48))

        self.img_saut = pg.image.load(path.join(self.dossier_img, 'saut.png')).convert_alpha()

        self.img_coffre_base_ferme = pg.image.load(path.join(self.dossier_img, 'chest_0.png')).convert_alpha()
        self.img_coffre_base_ferme = pg.transform.scale(self.img_coffre_base_ferme, (64, 64))
        self.img_coffre_base_ouvert = pg.image.load(path.join(self.dossier_img, 'chest_1.png')).convert_alpha()
        self.img_coffre_base_ouvert = pg.transform.scale(self.img_coffre_base_ouvert, (64, 64))
        self.img_coffre_cle_ferme = pg.image.load(path.join(self.dossier_img, 'chest_cle_0.png')).convert_alpha()
        self.img_coffre_cle_ferme = pg.transform.scale(self.img_coffre_cle_ferme, (64, 64))
        self.img_coffre_cle_ouvert = pg.image.load(path.join(self.dossier_img, 'chest_cle_1.png')).convert_alpha()
        self.img_coffre_cle_ouvert = pg.transform.scale(self.img_coffre_cle_ouvert, (64, 64))
        self.img_coffre_boss_ferme = pg.image.load(path.join(self.dossier_img, 'chest_boss_0.png')).convert_alpha()
        self.img_coffre_boss_ferme = pg.transform.scale(self.img_coffre_boss_ferme, (64, 64))
        self.img_coffre_boss_ouvert = pg.image.load(path.join(self.dossier_img, 'chest_boss_1.png')).convert_alpha()
        self.img_coffre_boss_ouvert = pg.transform.scale(self.img_coffre_boss_ouvert, (64, 64))
        self.img_coffre_spe_ferme = pg.image.load(path.join(self.dossier_img, 'chest_spe_0.png')).convert_alpha()
        self.img_coffre_spe_ferme = pg.transform.scale(self.img_coffre_spe_ferme, (64, 64))
        self.img_coffre_spe_ouvert = pg.image.load(path.join(self.dossier_img, 'chest_spe_1.png')).convert_alpha()
        self.img_coffre_spe_ouvert = pg.transform.scale(self.img_coffre_spe_ouvert, (64, 64))

        self.img_fond_coffre = pg.image.load(path.join(self.dossier_img, 'fond_coffre.png')).convert_alpha()

        self.img_fond_jeu = pg.image.load(path.join(self.dossier_img, 'fond_jeu.png')).convert_alpha()
        self.img_fenetre_quete = pg.image.load(path.join(self.dossier_img, 'fenetre_quete.png'))

        self.img_katana_1 = pg.image.load(path.join(self.dossier_img, 'katana_1.png')).convert_alpha()
        self.img_katana_2 = pg.image.load(path.join(self.dossier_img, 'katana_2.png')).convert_alpha()
        self.img_katana_3 = pg.image.load(path.join(self.dossier_img, 'katana_3.png')).convert_alpha()
        self.img_marteau_1 = pg.image.load(path.join(self.dossier_img, 'marteau_1.png')).convert_alpha()
        self.img_marteau_2 = pg.image.load(path.join(self.dossier_img, 'marteau_2.png')).convert_alpha()
        self.img_marteau_3 = pg.image.load(path.join(self.dossier_img, 'marteau_3.png')).convert_alpha()
        self.img_arc_1 = pg.image.load(path.join(self.dossier_img, 'arc_1.png')).convert_alpha()
        self.img_arc_2 = pg.image.load(path.join(self.dossier_img, 'arc_2.png')).convert_alpha()
        self.img_arc_3 = pg.image.load(path.join(self.dossier_img, 'arc_3.png')).convert_alpha()
        self.img_armure_1 = pg.image.load(path.join(self.dossier_img, 'armure_1.png')).convert_alpha()
        self.img_armure_1 = pg.transform.scale(self.img_armure_1, (48, 48))
        self.img_armure_2 = pg.image.load(path.join(self.dossier_img, 'armure_2.png')).convert_alpha()
        self.img_armure_2 = pg.transform.scale(self.img_armure_2, (48, 48))
        self.img_armure_3 = pg.image.load(path.join(self.dossier_img, 'armure_3.png')).convert_alpha()
        self.img_armure_3 = pg.transform.scale(self.img_armure_3, (48, 48))

        self.img_boutique_armurier = pg.image.load(path.join(self.dossier_img, 'boutique_armurier.png')).convert_alpha()
        self.img_boutique_armurier = pg.transform.scale(self.img_boutique_armurier, (535, 299))
        self.img_barre_dialogue = pg.image.load(path.join(self.dossier_img, 'barre_dialogue.png')).convert_alpha()
        self.img_barre_dialogue = pg.transform.scale(self.img_barre_dialogue, (535, 104))
        self.img_rang_select = pg.image.load(path.join(self.dossier_img, 'rang_select.png')).convert_alpha()
        self.img_rang_select = pg.transform.scale(self.img_rang_select, (255, 61))
        self.img_cache_rang = pg.image.load(path.join(self.dossier_img, 'cache_rang.png')).convert_alpha()
        self.img_cache_rang = pg.transform.scale(self.img_cache_rang, (261, 64))
        self.img_fond_quete = pg.image.load(path.join(self.dossier_img, 'fond_quete.png')).convert_alpha()

        self.img_player_droite_1 = pg.image.load(path.join(self.dossier_img, 'samurai_droite_1.png')).convert_alpha()
        self.img_player_droite_2 = pg.image.load(path.join(self.dossier_img, 'samurai_droite_2.png')).convert_alpha()
        self.img_player_droite_3 = pg.image.load(path.join(self.dossier_img, 'samurai_droite_3.png')).convert_alpha()
        self.img_player_gauche_1 = pg.image.load(path.join(self.dossier_img, 'samurai_gauche_1.png')).convert_alpha()
        self.img_player_gauche_2 = pg.image.load(path.join(self.dossier_img, 'samurai_gauche_2.png')).convert_alpha()
        self.img_player_gauche_3 = pg.image.load(path.join(self.dossier_img, 'samurai_gauche_3.png')).convert_alpha()
        self.img_player_face_1 = pg.image.load(path.join(self.dossier_img, 'samurai_face_1.png')).convert_alpha()
        self.img_player_face_2 = pg.image.load(path.join(self.dossier_img, 'samurai_face_2.png')).convert_alpha()
        self.img_player_face_3 = pg.image.load(path.join(self.dossier_img, 'samurai_face_3.png')).convert_alpha()
        self.img_player_dos_1 = pg.image.load(path.join(self.dossier_img, 'samurai_dos_1.png')).convert_alpha()
        self.img_player_dos_2 = pg.image.load(path.join(self.dossier_img, 'samurai_dos_2.png')).convert_alpha()
        self.img_player_dos_3 = pg.image.load(path.join(self.dossier_img, 'samurai_dos_3.png')).convert_alpha()
        self.player_img = self.img_player_face_1
        self.player_img = pg.transform.scale(self.player_img, (64, 64))

        self.img_mob_droite_1 = pg.image.load(path.join(self.dossier_img, 'mob_droite_1.png')).convert_alpha()
        self.img_mob_droite_1 = pg.transform.scale(self.img_mob_droite_1, (64, 64))
        self.img_mob_droite_2 = pg.image.load(path.join(self.dossier_img, 'mob_droite_2.png')).convert_alpha()
        self.img_mob_droite_2 = pg.transform.scale(self.img_mob_droite_2, (64, 64))
        self.img_mob_droite_3 = pg.image.load(path.join(self.dossier_img, 'mob_droite_3.png')).convert_alpha()
        self.img_mob_droite_3 = pg.transform.scale(self.img_mob_droite_3, (64, 64))
        self.img_mob_gauche_1 = pg.image.load(path.join(self.dossier_img, 'mob_gauche_1.png')).convert_alpha()
        self.img_mob_gauche_1 = pg.transform.scale(self.img_mob_gauche_1, (64, 64))
        self.img_mob_gauche_2 = pg.image.load(path.join(self.dossier_img, 'mob_gauche_2.png')).convert_alpha()
        self.img_mob_gauche_2 = pg.transform.scale(self.img_mob_gauche_2, (64, 64))
        self.img_mob_gauche_3 = pg.image.load(path.join(self.dossier_img, 'mob_gauche_3.png')).convert_alpha()
        self.img_mob_gauche_3 = pg.transform.scale(self.img_mob_gauche_3, (64, 64))
        self.img_mob_face_1 = pg.image.load(path.join(self.dossier_img, 'mob_face_1.png')).convert_alpha()
        self.img_mob_face_1 = pg.transform.scale(self.img_mob_face_1, (64, 64))
        self.img_mob_face_2 = pg.image.load(path.join(self.dossier_img, 'mob_face_2.png')).convert_alpha()
        self.img_mob_face_2 = pg.transform.scale(self.img_mob_face_2, (64, 64))
        self.img_mob_face_3 = pg.image.load(path.join(self.dossier_img, 'mob_face_3.png')).convert_alpha()
        self.img_mob_face_3 = pg.transform.scale(self.img_mob_face_3, (64, 64))
        self.img_mob_dos_1 = pg.image.load(path.join(self.dossier_img, 'mob_dos_1.png')).convert_alpha()
        self.img_mob_dos_1 = pg.transform.scale(self.img_mob_dos_1, (64, 64))
        self.img_mob_dos_2 = pg.image.load(path.join(self.dossier_img, 'mob_dos_2.png')).convert_alpha()
        self.img_mob_dos_2 = pg.transform.scale(self.img_mob_dos_2, (64, 64))
        self.img_mob_dos_3 = pg.image.load(path.join(self.dossier_img, 'mob_dos_3.png')).convert_alpha()
        self.img_mob_dos_3 = pg.transform.scale(self.img_mob_dos_3, (64, 64))
        self.mob_img = self.img_mob_face_2

        self.img_dragon_face = pg.image.load(path.join(self.dossier_img, 'dragon_face.png')).convert_alpha()
        self.img_dragon_face = pg.transform.scale(self.img_dragon_face, (64, 64))
        self.img_dragon_dos = pg.image.load(path.join(self.dossier_img, 'dragon_dos.png')).convert_alpha()
        self.img_dragon_dos = pg.transform.scale(self.img_dragon_dos, (64, 64))
        self.img_dragon_droite = pg.image.load(path.join(self.dossier_img, 'dragon_droite.png')).convert_alpha()
        self.img_dragon_droite = pg.transform.scale(self.img_dragon_droite, (64, 64))
        self.img_dragon_gauche = pg.image.load(path.join(self.dossier_img, 'dragon_gauche.png')).convert_alpha()
        self.img_dragon_gauche = pg.transform.scale(self.img_dragon_gauche, (64, 64))

        self.img_boss_gauche = pg.image.load(path.join(self.dossier_img, 'boss_gauche.png')).convert_alpha()
        self.img_boss_gauche = pg.transform.scale2x(self.img_boss_gauche)
        self.img_boss_droite = pg.image.load(path.join(self.dossier_img, 'boss_droite.png')).convert_alpha()
        self.img_boss_droite = pg.transform.scale2x(self.img_boss_droite)

        self.img_armurier = pg.image.load(path.join(self.dossier_img, 'pnj_armurier.png')).convert_alpha()
        self.img_armurier = pg.transform.scale(self.img_armurier, (47, 75))
        self.img_aubergiste = pg.image.load(path.join(self.dossier_img, 'pnj_aubergiste.png')).convert_alpha()
        self.img_aubergiste = pg.transform.scale(self.img_aubergiste, (47, 75))
        self.img_sorcier = pg.image.load(path.join(self.dossier_img, 'pnj_sorcier.png')).convert_alpha()
        self.img_sorcier = pg.transform.scale(self.img_sorcier, (47, 75))

        self.map_village = Map(self, path.join(self.dossier_maps, 'map_village_csv.tmx'))
        self.map_armurier = Map(self, path.join(self.dossier_maps, 'intérieur_armurier_csv.tmx'))
        self.map_auberge = Map(self, path.join(self.dossier_maps, 'auberge csv.tmx'))
        self.map_sorciere = Map(self, path.join(self.dossier_maps, 'boutique potion.tmx'))
        self.map_maison_1 = Map(self, path.join(self.dossier_maps, 'maison_niv1_csv.tmx'))
        self.map_maison_2 = Map(self, path.join(self.dossier_maps, 'maison_niv2_csv.tmx'))
        self.map_maison_3 = Map(self, path.join(self.dossier_maps, 'maison_niv3_csv.tmx'))
        self.map_maison_4 = Map(self, path.join(self.dossier_maps, 'maison_niv4_csv.tmx'))
        self.map_maison = self.map_maison_1
        self.map_foret_1 = Map(self, path.join(self.dossier_maps, 'map1 level1.tmx'))
        self.map_foret_2 = Map(self, path.join(self.dossier_maps, 'Labyrinthe csv.tmx'))
        self.map_foret_3 = Map(self, path.join(self.dossier_maps, 'donjon.tmx'))
        self.map_desert_1 = Map(self, path.join(self.dossier_maps, 'map1_level4_1.0.tmx'))
        self.map_desert_2 = Map(self, path.join(self.dossier_maps, 'map2_level4.tmx'))
        self.map_desert_3 = Map(self, path.join(self.dossier_maps, 'map3 level4.tmx'))
        self.map_foret_sombre_1 = Map(self, path.join(self.dossier_maps, 'map1_level3.tmx'))
        self.map_foret_sombre_2 = Map(self, path.join(self.dossier_maps, 'map2_level3_csv.tmx'))
        self.map_foret_sombre_3 = Map(self, path.join(self.dossier_maps, 'Map3 level3.tmx'))
        self.map_montagne_1 = Map(self, path.join(self.dossier_maps, 'map1 level5.tmx'))
        self.map_montagne_2 = Map(self, path.join(self.dossier_maps, 'map2_level5.tmx'))
        self.map_montagne_3 = Map(self, path.join(self.dossier_maps, 'map3 level5.tmx'))
        self.map_montagne_4 = Map(self, path.join(self.dossier_maps, 'map4 level5.tmx'))

        self.img_ecran_pause = pg.image.load(path.join(self.dossier_img, 'ecran_pause.png')).convert_alpha()
        self.img_ecran_menu = pg.image.load(path.join(self.dossier_img, 'ecran_menu.png')).convert_alpha()
        self.img_ecran_game_over = pg.image.load(path.join(self.dossier_img, 'ecran_game_over.png')).convert_alpha()
        self.img_ecran_jeu_termine = pg.image.load(path.join(self.dossier_img, 'ecran_jeu_termine.png')).convert_alpha()
        self.img_ecran_newGame = pg.image.load(path.join(self.dossier_img, 'ecran_nouvellePartie.png')).convert_alpha()

        self.img_slash_haut = pg.image.load(path.join(self.dossier_img, 'slash_haut.png'))
        self.img_slash_bas = pg.image.load(path.join(self.dossier_img, 'slash_bas.png'))
        self.img_slash_droite = pg.image.load(path.join(self.dossier_img, 'slash_droite.png'))
        self.img_slash_gauche = pg.image.load(path.join(self.dossier_img, 'slash_gauche.png'))

        self.img_fleche = pg.image.load(path.join(self.dossier_img, 'img_fleche.png')).convert_alpha()
        self.img_boule_feu = pg.image.load(path.join(self.dossier_img, 'boule_feu.png')).convert_alpha()
        self.img_orbe_magique = pg.image.load(path.join(self.dossier_img, 'orbes_magique.png')).convert_alpha()
        self.img_orbe_magique = pg.transform.scale2x(self.img_orbe_magique)

    def draw_text(self, text, font_name, size, color, x, y, align="topleft"):
        font = pg.font.Font(font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect(**{align: (x, y)})
        self.ecran.blit(text_surface, text_rect)

    def new(self):
        """
        initialise toutes les variables nécessaire au début d'une nouvelle partie.
        """
        self.all_sprites = pg.sprite.LayeredUpdates()
        self.walls = pg.sprite.Group()
        self.grilles = pg.sprite.Group()
        self.mobs = pg.sprite.Group()
        self.projectiles = pg.sprite.Group()
        self.pnj = pg.sprite.Group()
        self.portes = pg.sprite.Group()
        self.spawns = pg.sprite.Group()
        self.teleports = pg.sprite.Group()
        self.tresors = pg.sprite.Group()

        self.player = Player(self, 0, 0, self.player_img)
        self.map = self.map_village
        self.charger_map()
        self.currentLocation = 'Village'
        self.previousLocation = 'Maison'
        for spawn in self.spawns:
            if self.previousLocation == spawn.name:
                self.player.set_coord(spawn.rect.centerx, spawn.rect.centery)
        self.camera = Camera(self.map.width, self.map.height)
        self.paused = False
        self.clic = False
        self.dialogueEnCours = False
        self.chronoVitesse = 0
        self.chronoDegat = 0
        self.lectureCoffre = False
        self.coffreActuel = None
        self.queteAffiche = False
        self.jeu_en_cours = False
        self.partieTermine = False
        self.partie_enregistre = False
        self.ecran_newGame_affiche = False
        self.gameOver = False
        texte = ["Des Villageois ont été enlevés par des",
                 "monstres pendant qu'ils cueillaient des",
                 "champignons dans la forêt. Retrouvez",
                 "les, tuez les monstres et ramenez les",
                 "villageois au village."]
        recompense = ["Récompenses : ",
                      " -   + 25 xp",
                      " -   + 200 $",
                      " -   + coffres bonus"]
        recompenseInt = {'xp': 25, 'or': 750}
        self.quete1 = {'texte': texte, 'recompense': recompense,'recompenseInt':recompenseInt, 'numero': 1}
        texte = ["Mes bijoux de famille ont été dérobés",
                 "par des monstres. Leur base se trouve",
                 "dans la forêt maudite. Tuez les",
                 "monstres et ramenez moi mes bijoux de",
                 "famille."]
        recompense = ["Récompenses : ",
                      " -   + 25 xp",
                      " -   + 1000 $",
                      " -   + coffres bonus"]
        recompenseInt = {'xp': 25, 'or': 2000}
        self.quete3 = {'texte': texte, 'recompense': recompense,'recompenseInt':recompenseInt, 'numero': 2}
        texte = ["J'ai perdu mon saut dans le puis quand",
                 "je suis allé chercher de l'eau dans le",
                 "desert. Ramenez le moi s'il vous plait,",
                 "j'y tiens beaucoup."]
        recompense = ["Récompenses : ",
                      " -   + 25 xp",
                      " -   + 300 $",
                      " -   + coffres bonus"]
        recompenseInt = {'xp': 25, 'or': 500}
        self.quete2 = {'texte': texte, 'recompense': recompense,'recompenseInt':recompenseInt, 'numero': 3}
        texte = ["\"Je me demande bien si quelque chose se",
                 "trouve au sommet de la montagne... Se serait",
                 "un super endroit pour cacher un trésor...",
                 "Mais bon c'est infesté de monstres, il",
                 "faudrait être un héros pour y aller...\""]
        recompense = ["Récompenses : ",
                      " -   + 25 xp",
                      " -   + 10 000 $",
                      " -   + coffres bonus"]
        recompenseInt = {'xp': 25, 'or': 5000}
        self.quete4 = {'texte': texte, 'recompense': recompense,'recompenseInt':recompenseInt, 'numero': 4}

    def load_save(self):
        with open("save.txt", 'r') as fichier:
            if fichier.readline()[0:-1] == 'true':
                sauvegarde = True
                self.currentLocation = fichier.readline()[0:-1]
                self.previousLocation = fichier.readline()[0:-1]
                self.set_map_by_location()
                self.player.xp = int(fichier.readline()[0:-1])
                self.player.vie = int(fichier.readline()[0:-1])
                self.player.fleche = int(fichier.readline()[0:-1])
                self.player.argent = int(fichier.readline()[0:-1])
                numeroQuete = fichier.readline()[0:-1]
                if numeroQuete == 1:
                    self.player.queteEnCours = self.quete1
                if numeroQuete == 2:
                    self.player.queteEnCours = self.quete2
                if numeroQuete == 3:
                    self.player.queteEnCours = self.quete3
                if numeroQuete == 4:
                    self.player.queteEnCours = self.quete4
                queteTermine = fichier.readline()[0:-1]
                if queteTermine == 'True':
                    self.player.queteTermine = True
                else:
                    self.player.queteTermine = False
                equipement = {}
                equipement['armure'] = fichier.readline()[0:-1]
                equipement['arme'] = fichier.readline()[0:-1]
                equipement['potion'] = fichier.readline()[0:-1]
                for i in range(24):
                    case = 'case' + str(i)
                    equipement[case] = fichier.readline()[0:-1]
                for indice, item in equipement.items():
                    if item == 'Armure de voyageur':
                        self.player.inventaire[indice] = Armure(self.img_armure_1, 5, 'Armure de voyageur', 200)
                    elif item == 'Armure de chevalier':
                        self.player.inventaire[indice] = Armure(self.img_armure_2, 7, 'Armure de chevalier', 400)
                    elif item == 'Armure légendaire':
                        self.player.inventaire[indice] = Armure(self.img_armure_3, 10, 'Armure légendaire', 1200)
                    elif item == 'Katana de voyageur':
                        self.player.inventaire[indice] = Arme(self.img_katana_1, 25, 'katana', 'Katana de voyageur', 200)
                    elif item == 'Katana de chevalier':
                        self.player.inventaire[indice] = Arme(self.img_katana_2, 35, 'katana', 'Katana de chevalier', 400)
                    elif item == 'Katana légendaire':
                        self.player.inventaire[indice] = Arme(self.img_katana_3, 100, 'katana', 'Katana légendaire', 2000, 'feu')
                    elif item == 'Arc de voyageur':
                        self.player.inventaire[indice] = Arme(self.img_arc_1, 20, 'arc', 'Arc de voyageur', 100)
                    elif item == 'Arc de chevalier':
                        self.player.inventaire[indice] = Arme(self.img_arc_2, 30, 'arc', 'Arc de chevalier', 400)
                    elif item == 'Arc légendaire':
                        self.player.inventaire[indice] = Arme(self.img_arc_3, 150, 'arc', 'Arc légendaire', 2000, 'glace')
                    elif item == 'Marteau de voyageur':
                        self.player.inventaire[indice] = Arme(self.img_marteau_1, 35, 'marteau', 'Marteau de voyageur', 250)
                    elif item == 'Marteau de chevalier':
                        self.player.inventaire[indice] = Arme(self.img_marteau_2, 50, 'marteau', 'Marteau de chevalier', 500)
                    elif item == 'Marteau légendaire':
                        self.player.inventaire[indice] = Arme(self.img_marteau_3, 200, 'marteau', 'Marteau légendaire', 3000, 'foudre')
                    elif item == 'Potion de vitesse':
                        self.player.inventaire[indice] = Potion(self, self.img_potion_vitesse, 'vitesse', 'Potion de vitesse', 100)
                    elif item == 'Potion de vie':
                        self.player.inventaire[indice] = Potion(self, self.img_potion_vie, 'vie', 'Potion de vie', 100)
                    elif item == 'Potion de degat':
                        self.player.inventaire[indice] = Potion(self, self.img_potion_degat, 'degat', 'Potion de degat', 75)
                    elif item == 'Clé':
                        self.player.inventaire[indice] = Cle(self.img_cle, 'Clé')
                    elif item == 'Saut':
                        self.player.inventaire[indice] = Item(self.img_saut, 'Saut')
                    elif item == 'Bijoux de famille':
                        self.player.inventaire[indice] = Item(self.img_bijouxFamille, 'Bijoux de famille')
                    elif item == 'None':
                        self.player.inventaire[indice] = None
            else:
                sauvegarde = False
        return sauvegarde

    def save_game(self):
        with open("save.txt", 'w') as fichier:
            fichier.write("true\n")
            fichier.write(self.currentLocation + "\n")
            fichier.write(self.previousLocation + "\n")
            fichier.write(str(self.player.xp) + "\n")
            fichier.write(str(self.player.vie) + "\n")
            fichier.write(str(self.player.fleche) + "\n")
            fichier.write(str(self.player.argent) + "\n")
            if self.player.queteEnCours is None:
                fichier.write("None\n")
            else:
                fichier.write(str(self.player.queteEnCours['numero']) + "\n")
            fichier.write(str(self.player.queteTermine))
            if self.player.inventaire['armure'] is None:
                fichier.write("None\n")
            else:
                fichier.write(self.player.inventaire['armure'].nom + "\n")
            if self.player.inventaire['arme'] is None:
                fichier.write("None\n")
            else:
                fichier.write(self.player.inventaire['arme'].nom + "\n")
            if self.player.inventaire['potion'] is None:
                fichier.write("None\n")
            else:
                fichier.write(self.player.inventaire['potion'].nom + "\n")
            for i in range(24):
                if self.player.inventaire['case'+str(i)] is None:
                    fichier.write("None\n")
                else:
                    fichier.write(self.player.inventaire['case'+str(i)].nom + "\n")

    def run(self):
        self.events()
        if self.jeu_en_cours:
            if not self.paused and not self.player.inventaireOuvert and not self.dialogueEnCours and not self.lectureCoffre:
                self.update()
            self.draw()
        elif self.partieTermine:
            choix = self.afficher_ecran_jeu_termine()
            if choix == 'quitter':
                self.save_game()
                pg.quit()
                sys.exit(0)
            elif choix == 'menu':
                self.partieTermine = False
                self.partie_enregistre = False
        elif self.ecran_newGame_affiche:
            self.afficher_ecran_newGame()
        else:
            self.afficher_ecran_menu()

        pg.display.flip()

    def events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.save_game()
                pg.quit()
                sys.exit(0)
            if pg.mouse.get_pressed(3)[0]:
                self.mousse_pressed = True
            if not pg.mouse.get_pressed(3)[0]:
                self.clic = False
                self.mousse_pressed = False
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_ESCAPE:
                    self.paused = not self.paused
                    # ouvre le menu pause avec quitter/controles...
                if event.key == pg.K_SPACE and not self.paused:
                    self.player.attaque()
                if event.key == pg.K_d or event.key == pg.K_RIGHT and not self.paused:
                    self.player.direction = "DROITE"
                    self.player.vitesseX = 1.25 + self.player.boostVitesse
                    self.player.vitesseY = 0
                if event.key == pg.K_q or event.key == pg.K_LEFT and not self.paused:
                    self.player.direction = "GAUCHE"
                    self.player.vitesseX = -1.25 - self.player.boostVitesse
                    self.player.vitesseY = 0
                if event.key == pg.K_z or event.key == pg.K_UP and not self.paused:
                    self.player.direction = "HAUT"
                    self.player.vitesseY = -1.25 - self.player.boostVitesse
                    self.player.vitesseX = 0
                if event.key == pg.K_s or event.key == pg.K_DOWN and not self.paused:
                    self.player.direction = "BAS"
                    self.player.vitesseY = 1.25 + self.player.boostVitesse
                    self.player.vitesseX = 0
                if event.key == pg.K_e and not self.paused:
                    self.player.inventaireOuvert = not self.player.inventaireOuvert
                if event.key == pg.K_f and self.player.dansZonePnj and not self.paused:
                    self.dialogueEnCours = True
                if event.key == pg.K_r and self.player.inventaire['potion'] is not None and not self.paused:
                    self.player.inventaire['potion'].utiliser(self.player)
            if event.type == pg.KEYUP:
                if event.key == pg.K_d or event.key == pg.K_RIGHT:
                    self.player.vitesseX = 0
                if event.key == pg.K_q or event.key == pg.K_LEFT:
                    self.player.vitesseX = 0
                if event.key == pg.K_z or event.key == pg.K_UP:
                    self.player.vitesseY = 0
                if event.key == pg.K_s or event.key == pg.K_DOWN:
                    self.player.vitesseY = 0

    def update(self):
        if self.player.est_vivant():
            if pg.time.get_ticks() - self.chronoVitesse < 8000 and self.chronoVitesse > 0:
                self.player.boostVitesse = 0.25
            else:
                self.player.boostVitesse = 0
            if pg.time.get_ticks() - self.chronoDegat < 8000 and self.chronoDegat > 0:
                self.player.boostDegat = 15
            else:
                self.player.boostDegat = 0
            self.all_sprites.update()
            self.camera.update(self.player)
        else:
            self.gameOver = True

    def draw(self):
        if self.player.inventaireOuvert:
            self.player.afficher_inventaire()
        elif self.gameOver:
            choix = self.afficher_ecran_game_over()
            if choix == 'respawn':
                self.respawn_player()
            elif choix == 'menu':
                self.respawn_player()
                self.jeu_en_cours = False
        elif self.dialogueEnCours:
            self.player.pnjProche.afficher_dialogue()
            if self.player.pnjProche.boutiqueOuverte:
                self.events()
                self.player.pnjProche.afficher_boutique()
        elif self.lectureCoffre and self.coffreActuel.affichageEnCours:
            if self.coffreActuel.afficher_contenu() == 'quitter':
                self.lectureCoffre = False
        elif self.paused:
            self.afficher_ecran_pause()
        else:
            self.ecran.fill([0, 0, 0])
            if self.map.width < FENETRE_LONGUEUR and self.map.height < FENETRE_LARGEUR:
                self.ecran.blit(self.map_img, (FENETRE_LONGUEUR/2-self.map.width/2, FENETRE_LARGEUR/2-self.map.height/2))
                for sprite in self.all_sprites:
                    # if isinstance(sprite, (Mob, Dragon, Boss)):
                    #     sprite.draw_health()
                    x = sprite.rect.x + FENETRE_LONGUEUR/2-self.map.width/2
                    y = sprite.rect.y + FENETRE_LARGEUR/2-self.map.height/2
                    self.ecran.blit(sprite.image, (x, y))
            else:
                self.ecran.blit(self.map_img, self.camera.aligner(self.map))
                for sprite in self.all_sprites:
                    # if isinstance(sprite, (Mob, Dragon, Boss)):
                    #     sprite.draw_health()
                    self.ecran.blit(sprite.image, self.camera.aligner(sprite))
            if self.player.dansZonePnj:
                self.draw_text('F pour parler', self.font_ecriture, 17, [255, 255, 255], 684, 623)
            self.afficher_fond_jeu()
            if self.player.enAttaque and self.player.inventaire['arme'].type != 'arc':
                rect = self.img_slash_haut.get_rect()
                rect.x = self.player.x-70
                rect.y = self.player.y-60
                self.camera.aligner_rect(rect)
                if self.player.direction == 'HAUT':
                    self.ecran.blit(self.img_slash_haut, self.camera.aligner_rect(rect))
                elif self.player.direction == 'BAS':
                    rect.y += 50
                    self.ecran.blit(self.img_slash_bas, self.camera.aligner_rect(rect))
                elif self.player.direction == 'DROITE':
                    self.ecran.blit(self.img_slash_droite, self.camera.aligner_rect(rect))
                elif self.player.direction == 'GAUCHE':
                    self.ecran.blit(self.img_slash_gauche, self.camera.aligner_rect(rect))
        pg.display.flip()

    def afficher_fond_jeu(self):
        # fond
        self.ecran.blit(self.img_fond_jeu, (0, 0))
        # vie
        x = 21
        y = 52
        for i in range(0, self.player.vie, 3):
            if i == 0:
                self.ecran.blit(self.img_inv_vie_1, (x, y))
            elif i == 99:
                self.ecran.blit(self.img_inv_vie_3, (x, y))
            else:
                self.ecran.blit(self.img_inv_vie_2, (x, y))
            x += 7
        # xp
        x = 21
        y = 22
        for i in range(0, self.player.xp, 3):
            if i == 0:
                self.ecran.blit(self.img_inv_xp_1, (x, y))
            elif i == 99:
                self.ecran.blit(self.img_inv_xp_3, (x, y))
            else:
                self.ecran.blit(self.img_inv_xp_2, (x, y))
            x += 7
        # or
        self.draw_text(str(self.player.argent), self.font_ecriture, 15, [0, 0, 0], 85, 82, "topright")
        # items
        if self.player.inventaire['armure'] is not None:
            self.ecran.blit(self.player.inventaire['armure'].img, (46, 607))
        if self.player.inventaire['arme'] is not None:
            self.ecran.blit(self.player.inventaire['arme'].img, (108, 607))
        if self.player.inventaire['potion'] is not None:
            self.ecran.blit(self.player.inventaire['potion'].img, (170, 607))
        # quete
        if self.queteAffiche:
            # fond
            self.ecran.blit(self.img_fenetre_quete, (600, 14))
            # texte
            x = 623
            y = 34
            for ligne in self.player.queteEnCours['texte']:
                self.draw_text(ligne, self.font_ecriture, 13, [0, 0, 0], x, y)
                y += 20
            y = 133
            for ligne in self.player.queteEnCours['recompense']:
                self.draw_text(ligne, self.font_ecriture, 14, [0, 0, 0], x, y)
                y += 20
        # boutons
        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 1010 < x < 1010 + 54 and 16 < y < 16 + 54 and self.player.queteEnCours is not None:
                self.queteAffiche = not self.queteAffiche
            if 1010 < x < 1010 + 54 and 76 < y < 76 + 54:
                self.paused = True

    def afficher_ecran_pause(self):
        self.ecran.blit(self.img_ecran_pause, (0, 0))

        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 359 < x < 359 + 157 and 249 < y < 249 + 35:
                # reprendre
                self.paused = False
            if 359 < x < 359 + 157 and 321 < y < 321 + 35:
                # sauvegarder + retour au menu
                self.save_game()
                self.jeu_en_cours = False
            if 359 < x < 359 + 157 and 393 < y < 393 + 35:
                # sauvegarder + quitter
                self.save_game()
                pg.quit()
                sys.exit(0)

    def afficher_ecran_menu(self):
        self.ecran.blit(self.img_ecran_menu, (0, 0))

        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 461 < x < 461 + 157 and 360 < y < 360 + 35:
                # reprendre la partie
                self.paused = False
                if self.load_save():
                    self.jeu_en_cours = True
            if 461 < x < 461 + 157 and 435 < y < 435 + 35:
                # Nouvelle partie
                self.new()
                self.ecran_newGame_affiche = True
            if 461 < x < 461 + 157 and 504 < y < 504 + 35:
                # quitter
                pg.quit()
                sys.exit(0)

    def afficher_ecran_game_over(self):
        self.ecran.blit(self.img_ecran_game_over, (0, 0))
        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 544 < x < 544 + 157 and 358 < y < 358 + 35:
                return 'respawn'
            elif 380 < x < 380 + 157 and 358 < y < 358 + 35:
                return 'menu'

    def afficher_ecran_jeu_termine(self):
        self.ecran.blit(self.img_ecran_jeu_termine, (0, 0))
        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 544 < x < 544 + 157 and 358 < y < 358 + 35:
                return 'quitter'
            elif 380 < x < 380 + 157 and 358 < y < 358 + 35:
                return 'menu'

    def afficher_ecran_newGame(self):
        self.ecran.blit(self.img_ecran_newGame, (0, 0))
        if self.mousse_pressed and not self.clic:
            self.clic = True
            x, y = pg.mouse.get_pos()
            if 461 < x < 461 + 157 and 568 < y < 568 + 35:
                self.jeu_en_cours = True
                self.ecran_newGame_affiche = False

    def collide_with_walls(self, sprite, group, dir):
        if dir == 'x':
            hits = pg.sprite.spritecollide(sprite, group, False)
            if hits:
                if hits[0].rect.centerx > sprite.hitbox.centerx:
                    sprite.x = hits[0].rect.left - sprite.hitbox.width / 2
                if hits[0].rect.centerx < sprite.hitbox.centerx:
                    sprite.x = hits[0].rect.right + sprite.hitbox.width / 2
                sprite.vitesseX = 0
                sprite.hitbox.centerx = sprite.x
        if dir == 'y':
            hits = pg.sprite.spritecollide(sprite, group, False)
            if hits:
                if hits[0].rect.centery > sprite.hitbox.centery:
                    sprite.y = hits[0].rect.top - sprite.hitbox.height / 2
                if hits[0].rect.centery < sprite.hitbox.centery:
                    sprite.y = hits[0].rect.bottom + sprite.hitbox.height / 2
                sprite.vitesseY = 0
                sprite.hitbox.centery = sprite.y

    def collide_with_pnj(self, sprite, group):
        hits = pg.sprite.spritecollide(sprite, group, False, collide_hitbox)
        if hits:
            self.player.dansZonePnj = True
            self.player.pnjProche = hits[0]
        else:
            self.player.dansZonePnj = False
            self.player.pnjProche = None

    def collide_with_porte(self, sprite, group):
        hits = pg.sprite.spritecollide(sprite, group, False)
        if hits:
            self.previousLocation = self.currentLocation
            self.currentLocation = hits[0].name
            self.set_map_by_location()

    def collide_with_teleports(self, sprite, group):
        hits = pg.sprite.spritecollide(sprite, group, False)
        if hits:
            self.previousLocation = 'Maison'
            self.currentLocation = 'Village'
            self.set_map_by_location()

    def collide_with_coffre(self, sprite, group):
        hits = pg.sprite.spritecollide(sprite, group, False)
        if hits:
            if not hits[0].ouvert:
                self.lectureCoffre = True
                self.coffreActuel = hits[0]
                self.coffreActuel.affichageEnCours = True
                if hits[0].type == 'Coffre Légendaire 1' or hits[0].type == 'Coffre level2' or hits[0].type == 'Coffre level3' or hits[0].type == 'Coffre Légendaire 4':
                    self.player.queteTermine = True

    def collide_with_grille(self, sprite, group, dir):
        hits = pg.sprite.spritecollide(sprite, group, False)
        if hits:
            if self.player.est_dans_inventaire('Clé de donjon'):
                hits[0].ouvert = True
                self.player.retirer_de_inventaire('Clé de donjon')
            else:
                self.draw_text('Il vous faut une clé pour ouvrir cette grille !', self.font_ecriture, 12, [255, 255, 255], FENETRE_LONGUEUR/2-120, FENETRE_LARGEUR-160, )
            if not hits[0].ouvert:
                if dir == 'x':
                    hits = pg.sprite.spritecollide(sprite, group, False)
                    if hits:
                        if hits[0].rect.centerx > sprite.hitbox.centerx:
                            sprite.x = hits[0].rect.left - sprite.hitbox.width / 2
                        if hits[0].rect.centerx < sprite.hitbox.centerx:
                            sprite.x = hits[0].rect.right + sprite.hitbox.width / 2
                        sprite.vitesseX = 0
                        sprite.hitbox.centerx = sprite.x
                if dir == 'y':
                    hits = pg.sprite.spritecollide(sprite, group, False)
                    if hits:
                        if hits[0].rect.centery > sprite.hitbox.centery:
                            sprite.y = hits[0].rect.top - sprite.hitbox.height / 2
                        if hits[0].rect.centery < sprite.hitbox.centery:
                            sprite.y = hits[0].rect.bottom + sprite.hitbox.height / 2
                        sprite.vitesseY = 0
                        sprite.hitbox.centery = sprite.y

    def collide_with_mobs(self, sprite, group):
        hits = pg.sprite.spritecollide(sprite, group, False)
        for hit in hits:
            if isinstance(hit, Mob) and pg.time.get_ticks()-hit.repos > 500:
                self.player.vie -= hit.degat - self.player.resistance
                hit.repos = pg.time.get_ticks()
        if hits:
            if self.player.direction == 'DROITE':
                self.player.x -= 40
            elif self.player.direction == 'GAUCHE':
                self.player.x += 40
            elif self.player.direction == 'BAS':
                self.player.y -= 40
            elif self.player.direction == 'HAUT':
                self.player.y += 40
            self.player.vitesseX = 0
            self.player.vitesseY = 0

    def set_map_by_location(self):
        self.kill_map_objects()
        if self.currentLocation == 'Village':
            self.map = self.map_village
        elif self.currentLocation == 'Armurier':
            self.map = self.map_armurier
        elif self.currentLocation == 'Auberge':
            self.map = self.map_auberge
        elif self.currentLocation == 'Sorciere':
            self.map = self.map_sorciere
        elif self.currentLocation == 'Maison':
            self.map = self.map_maison
        elif self.currentLocation == 'Foret1':
            self.map = self.map_foret_1
        elif self.currentLocation == 'Foret2':
            self.map = self.map_foret_2
        elif self.currentLocation == 'Foret3':
            self.map = self.map_foret_3
        elif self.currentLocation == 'ForetSombre1':
            self.map = self.map_foret_sombre_1
        elif self.currentLocation == 'ForetSombre2':
            self.map = self.map_foret_sombre_2
        elif self.currentLocation == 'ForetSombre3':
            self.map = self.map_foret_sombre_3
        elif self.currentLocation == 'Desert1':
            self.map = self.map_desert_1
        elif self.currentLocation == 'Desert2':
            self.map = self.map_desert_2
        elif self.currentLocation == 'Desert3':
            self.map = self.map_desert_3
        elif self.currentLocation == 'Montagne1':
            self.map = self.map_montagne_1
        elif self.currentLocation == 'Montagne2':
            self.map = self.map_montagne_2
        elif self.currentLocation == 'Montagne3':
            self.map = self.map_montagne_3
        elif self.currentLocation == 'Montagne4':
            self.map = self.map_montagne_4
        self.charger_map()
        for spawn in self.spawns:
            if self.previousLocation == spawn.name:
                self.player.set_coord(spawn.rect.centerx, spawn.rect.centery)
                self.camera = Camera(self.map.width, self.map.height)

    def charger_map(self):
        self.map_img = self.map.make_map()
        self.map.rect = self.map_img.get_rect()
        for tile_object in self.map.tmxdata.objects:
            obj_center = (tile_object.x + tile_object.width / 2, tile_object.y + tile_object.height / 2)
            if tile_object.name == 'coffre_item':
                Tresor(self, self.img_coffre_base_ferme, self.img_coffre_base_ouvert, 'Coffre Basique', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_cle':
                Tresor(self, self.img_coffre_cle_ferme, self.img_coffre_cle_ouvert, 'Coffre Clé', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_boss_1':
                Tresor(self, self.img_coffre_boss_ferme, self.img_coffre_boss_ouvert, 'Coffre Légendaire 1', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_boss_2':
                Tresor(self, self.img_coffre_boss_ferme, self.img_coffre_boss_ouvert, 'Coffre Légendaire 2', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_boss_3':
                Tresor(self, self.img_coffre_boss_ferme, self.img_coffre_boss_ouvert, 'Coffre Légendaire 3', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_boss_4':
                Tresor(self, self.img_coffre_boss_ferme, self.img_coffre_boss_ouvert, 'Coffre Légendaire 4', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_level2':
                Tresor(self, self.img_coffre_spe_ferme, self.img_coffre_spe_ouvert, 'Coffre level2', tile_object.x, tile_object.y)
            if tile_object.name == 'coffre_level3':
                Tresor(self, self.img_coffre_spe_ferme, self.img_coffre_spe_ouvert, 'Coffre level3', tile_object.x, tile_object.y)
            if tile_object.name == 'Armurier':
                Armurier(self, 'Armurier', tile_object.x, tile_object.y, self.img_armurier)
            if tile_object.name == 'Sorcier':
                Sorcier(self, 'sorcier', tile_object.x, tile_object.y, self.img_sorcier)
            if tile_object.name == 'Aubergiste':
                Aubergiste(self, 'aubergiste', tile_object.x, tile_object.y, self.img_aubergiste)
            if tile_object.name == 'mob':
                Mob(self, tile_object.x, tile_object.y, self.mob_img)
            if tile_object.name == 'mob_dist':
                Dragon(self, tile_object.x, tile_object.y)
            if tile_object.name == 'boss_1':
                Boss(self, tile_object.x, tile_object.y, 1)
            if tile_object.name == 'boss_2':
                Boss(self, tile_object.x, tile_object.y, 2)
            if tile_object.name == 'boss_3':
                Boss(self, tile_object.x, tile_object.y, 3)
            if tile_object.name == 'Wall':
                Obstacle(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
            if tile_object.name == 'Grille':
                Grille(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
            if "Porte" in tile_object.name:
                name = tile_object.name[6:]
                Porte(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, name)
            if "Sortie" in tile_object.name:
                name = tile_object.name[7:]
                Spawn(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, name)
            if tile_object.name == 'Teleportation':
                Teleportation(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height, tile_object.name)

    def kill_map_objects(self):
        for sprite in self.walls:
            sprite.kill()
        for sprite in self.mobs:
            sprite.kill()
        for sprite in self.portes:
            sprite.kill()
        for sprite in self.projectiles:
            sprite.kill()
        for sprite in self.spawns:
            sprite.kill()
        for sprite in self.pnj:
            sprite.kill()
        for sprite in self.tresors:
            sprite.kill()
        for sprite in self.teleports:
            sprite.kill()

    def respawn_player(self):
        self.currentLocation = 'Village'
        self.previousLocation = 'Maison'
        self.set_map_by_location()
        self.player.vie = 100
        self.gameOver = False


def collide_hitbox(one, two):
    return one.hitbox.colliderect(two.hitbox)


jeu = Jeu()
jeu.new()
while True:
    jeu.run()


