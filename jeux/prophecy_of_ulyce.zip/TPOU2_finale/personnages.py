import pygame as pg
from constantes import *
from items import *
# from main import *
vec = pg.math.Vector2


class Player(pg.sprite.Sprite):
    def __init__(self, jeu, x, y, IMAGE):
        self._layer = PLAYER_LAYER
        self.groups = jeu.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.jeu = jeu
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.center = (x, y)
        self.hitbox = PLAYER_HITBOX
        self.hitbox.center = self.rect.center
        self.vitesseX = 0
        self.vitesseY = 0
        self.x = x
        self.y = y
        self.direction = "DROITE"
        #
        self.last_shot = 0
        self.damaged = False
        self.argent = 200
        self.vieOrigin = 100
        self.xp = 0
        self.vie = 100
        self.degat = 0
        self.mana = 0
        self.fleche = 100
        self.type = ""
        self.nom = "Ulyce"
        self.inventaire = {'armure': None, 'arme': None, 'potion': None,
                           'case0': Potion(self.jeu, self.jeu.img_potion_vie, 'vie', 'Potion de vie'), 'case1': Arme(self.jeu.img_arc_1, 20, 'arc', 'Arc de voyageur', 100), 'case2': None, 'case3': None,
                           'case4': None, 'case5': None, 'case6': None, 'case7': None,
                           'case8': None, 'case9': None, 'case10': None, 'case11': None,
                           'case12': None, 'case13': None, 'case14': None, 'case15': None,
                           'case16': None, 'case17': None, 'case18': None, 'case19': None,
                           'case20': None, 'case21': None, 'case22': None, 'case23': None}
        self.inventaireOuvert = False
        self.infoOuvert = False
        self.case_select = ''
        self.skin = ""
        self.armure = ""
        self.arme = ""
        self.potion = ""

        self.image = IMAGE
        self.pas = 1
        self.depuisPas = 0

        self.dansZonePnj = False
        self.pnjProche = None

        self.queteEnCours = None
        self.queteTermine = False

        self.boostVitesse = 0
        self.boostDegat = 0
        self.enAttaque = False
        self.resistance = 0

    def get_vie(self):
        return self.vie
    def get_degat(self):
        return self.degat
    def get_mana(self):
        return self.mana
    def get_fleche(self):
        return self.fleche
    def get_type(self):
        return self.type
    def get_nom(self):
        return self.nom
    def get_inventaire(self):
        return self.inventaire
    def get_skin(self):
        return self.skin
    def get_armure(self):
        return self.armure
    def get_arme(self):
        return self.arme
    def get_potion(self):
        return self.potion

    def set_coord(self, x, y):
        self.x = x
        self.y = y

    # def devient_guerrier(self):
    #     self.type = "GUERRIER"
    #     self.vitesse = 25
    #     self.vie = 125
    #     self.vieOrigin = self.vie
    #     self.degat = 75
    #     self.skin = SKIN_GUERRIER_DROITE
    #
    # def devient_samourai(self):
    #     self.type = "SAMOURAI"
    #     self.vitesse = 125
    #     self.vie = 50
    #     self.vieOrigin = self.vie
    #     self.degat = 125
    #     self.skin = SKIN_SAMOURAI_DROITE
    #
    # def devient_archer(self):
    #     self.type = "ARCHER"
    #     self.vitesse = 100
    #     self.vie = 25
    #     self.vieOrigin = self.vie
    #     self.degat = 100
    #     self.fleche = 10
    #     self.skin = SKIN_ARCHER_DROITE
    #
    # def devient_mage(self):
    #     self.type = "MAGE"
    #     self.vitesse = 75
    #     self.vie = 50
    #     self.vieOrigin = self.vie
    #     self.degat = 125
    #     self.mana = 15
    #     self.skin = SKIN_MAGE_DROITE

    def equiper_arme(self, x):
        self.arme = x
    def equiper_armure(self, x):
        self.armure = x
    def equiper_potion(self, x):
        self.potion = x
    def nommer(self,x):
        self.nom = x

    def est_vivant(self):
        return self.vie > 0

    def update(self):
        self.x += self.vitesseX
        if not self.rect.width/2 < self.x < self.jeu.map.width - self.rect.width/2:
            self.x -= self.vitesseX

        self.y += self.vitesseY
        if not self.rect.height/2 < self.y < self.jeu.map.height - self.rect.height/2:
            self.y -= self.vitesseY

        self.rect.center = (self.x, self.y)
        self.hitbox.center = self.rect.center

        if self.vitesseX != 0:
            self.jeu.collide_with_walls(self, self.jeu.walls, 'x')
            self.jeu.collide_with_grille(self, self.jeu.grilles, 'x')
        if self.vitesseY != 0:
            self.jeu.collide_with_walls(self, self.jeu.walls, 'y')
            self.jeu.collide_with_grille(self, self.jeu.grilles, 'y')

        self.jeu.collide_with_mobs(self, self.jeu.mobs)

        self.jeu.collide_with_porte(self, self.jeu.portes)

        self.jeu.collide_with_pnj(self, self.jeu.pnj)

        self.jeu.collide_with_coffre(self, self.jeu.tresors)

        self.jeu.collide_with_teleports(self, self.jeu.teleports)

        if self.direction == 'DROITE':
            if self.vitesseX == 0:
                self.image = self.jeu.img_player_droite_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_player_droite_1
                if self.pas == 2:
                    self.image = self.jeu.img_player_droite_2
                if self.pas == 3:
                    self.image = self.jeu.img_player_droite_3
        if self.direction == 'GAUCHE':
            if self.vitesseX == 0:
                self.image = self.jeu.img_player_gauche_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_player_gauche_1
                if self.pas == 2:
                    self.image = self.jeu.img_player_gauche_2
                if self.pas == 3:
                    self.image = self.jeu.img_player_gauche_3
        if self.direction == 'BAS':
            if self.vitesseY == 0:
                self.image = self.jeu.img_player_face_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_player_face_1
                if self.pas == 2:
                    self.image = self.jeu.img_player_face_2
                if self.pas == 3:
                    self.image = self.jeu.img_player_face_3
        if self.direction == 'HAUT':
            if self.vitesseY == 0:
                self.image = self.jeu.img_player_dos_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_player_dos_1
                if self.pas == 2:
                    self.image = self.jeu.img_player_dos_2
                if self.pas == 3:
                    self.image = self.jeu.img_player_dos_3
        if self.depuisPas == 70:
            if self.pas == 3:
                self.pas = 1
            else:
                self.pas += 1
            self.depuisPas = 0
        self.depuisPas += 1

        if 0 < pg.time.get_ticks() - self.last_shot < 300:
            self.enAttaque = True
        else:
            self.enAttaque = False

        if self.xp == 0:
            self.jeu.map_maison = self.jeu.map_maison_1
        elif self.xp == 25:
            self.jeu.map_maison = self.jeu.map_maison_2
        elif self.xp == 50:
            self.jeu.map_maison = self.jeu.map_maison_3
        elif self.xp == 75:
            self.jeu.map_maison = self.jeu.map_maison_4
        elif self.xp == 100:
            self.jeu.jeu_en_cours= False
            self.jeu.partieTermine = True

    def attaque(self):
        arme = self.inventaire['arme']
        now = pg.time.get_ticks()
        if arme is not None:
            if now - self.last_shot > arme.rate:
                self.last_shot = now
                if arme.type == 'katana' or arme.type == 'marteau':
                    zone = pg.Rect(0, 0, 2.5*64, 2.5*64)
                    zone.center = self.rect.center
                    for mob in self.jeu.mobs:
                        if zone.colliderect(mob.rect):
                            mob.vie -= arme.degat + self.boostDegat
                            if mob.direction == 'DROITE':
                                mob.x -= 64
                            elif mob.direction == 'GAUCHE':
                                mob.x += 64
                            elif mob.direction == 'BAS':
                                mob.y -= 64
                            elif mob.direction == 'HAUT':
                                mob.y += 64
                else:
                    vecTir = vec(0, 0)
                    rotTir = 0
                    if self.direction == 'DROITE':
                        vecTir = vec(1, 0)
                        rotTir = -90
                    elif self.direction == 'GAUCHE':
                        vecTir = vec(-1, 0)
                        rotTir = 90
                    elif self.direction == 'HAUT':
                        vecTir = vec(0, -1)
                        rotTir = 0
                    elif self.direction == 'BAS':
                        vecTir = vec(0, 1)
                        rotTir = 180
                    Projectile(self.jeu, self.rect.centerx, self.rect.centery, vecTir, arme.degat + self.boostDegat,
                               pg.transform.rotate(self.jeu.img_fleche, rotTir), arme.vitesse_projectile, self)

    def afficher_inventaire(self):
        # fond
        x = FENETRE_LONGUEUR/2 - self.jeu.img_inventaire_fond.get_width()/2
        y = FENETRE_LARGEUR/2 - self.jeu.img_inventaire_fond.get_height()/2
        self.jeu.ecran.blit(self.jeu.img_inventaire_fond, (x, y))

        # vie
        x = 247.77
        y = 409.598
        for i in range(0, self.vie, 3):
            if i == 0:
                self.jeu.ecran.blit(self.jeu.img_inv_vie_1, (x, y))
            elif i == 99:
                self.jeu.ecran.blit(self.jeu.img_inv_vie_3, (x, y))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_vie_2, (x, y))
            x += 7
        # xp
        x = 247.77
        y = 371.088
        for i in range(0, self.xp, 3):
            if i == 0:
                self.jeu.ecran.blit(self.jeu.img_inv_xp_1, (x, y))
            elif i == 99:
                self.jeu.ecran.blit(self.jeu.img_inv_xp_3, (x, y))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_xp_2, (x, y))
            x += 7
        # degat
        x = 247.77
        y = 446.863
        for i in range(0, self.degat, 3):
            if i == 0:
                self.jeu.ecran.blit(self.jeu.img_inv_degat_1, (x, y))
            elif i == 99:
                self.jeu.ecran.blit(self.jeu.img_inv_degat_3, (x, y))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_degat_2, (x, y))
            x += 7
        # mana
        x = 247.77
        y = 485.15
        for i in range(0, self.mana, 3):
            if i == 0:
                self.jeu.ecran.blit(self.jeu.img_inv_mana_1, (x, y))
            elif i == 99:
                self.jeu.ecran.blit(self.jeu.img_inv_mana_3, (x, y))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_mana_2, (x, y))
            x += 7
        # fleche
        x = 247.77
        y = 522.746
        for i in range(0, self.fleche, 3):
            if i == 0:
                self.jeu.ecran.blit(self.jeu.img_inv_fleche_1, (x, y))
            elif i == 99:
                self.jeu.ecran.blit(self.jeu.img_inv_fleche_3, (x, y))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_fleche_2, (x, y))
            x += 7

        # armure
        if self.inventaire['armure'] is not None:
            if 'armure' == self.case_select:
                self.jeu.ecran.blit(self.jeu.img_inv_case_select, (209.715 - 5, 143.035 - 5))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_cache_case, (209.715, 143.035))
            self.jeu.ecran.blit(self.inventaire['armure'].img, (209.715, 143.035))
        # arme
        if self.inventaire['arme'] is not None:
            if 'arme' == self.case_select:
                self.jeu.ecran.blit(self.jeu.img_inv_case_select, (337.558 - 5, 145.035 - 5))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_cache_case, (337.558, 145.035))
            self.jeu.ecran.blit(self.inventaire['arme'].img, (337.558, 145.035))
        # potion
        if self.inventaire['potion'] is not None:
            if 'potion' == self.case_select:
                self.jeu.ecran.blit(self.jeu.img_inv_case_select, (209.113 - 5, 267.292 - 5))
            else:
                self.jeu.ecran.blit(self.jeu.img_inv_cache_case, (209.113, 267.292))
            self.jeu.ecran.blit(self.inventaire['potion'].img, (209.113, 267.292))
        # inventaire
        for indice, item in self.inventaire.items():
            if 'case' in indice:
                X = (int(indice[4:]) % 4) * 60.4 + 611
                Y = (int(indice[4:]) // 4) * 60.4 + 164
                if item is not None:
                    if indice == self.case_select:
                        self.jeu.ecran.blit(self.jeu.img_inv_case_select, (X-5, Y-5))
                    self.jeu.ecran.blit(item.img, (X, Y))
        # fenetre info
        if self.infoOuvert and self.case_select != '':
            self.jeu.ecran.blit(self.jeu.img_inv_plus, (328.558, 220.087))
            img = self.inventaire[self.case_select].img
            img = pg.transform.scale(img, (64, 64))
            self.jeu.ecran.blit(img, (340, 250))
            self.jeu.draw_text(self.inventaire[self.case_select].nom, self.jeu.font_ecriture, 9, [0, 0, 0], 366, 227)
            if "<class 'items.Potion'>" == str(self.inventaire[self.case_select].__class__):
                if self.inventaire[self.case_select].type == 'vie':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_vie, (420, 277))
                elif self.inventaire[self.case_select].type == 'vitesse':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_vitesse, (420, 277))
                elif self.inventaire[self.case_select].type == 'degat':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_degat, (420, 277))
            elif "<class 'items.Arme'>" == str(self.inventaire[self.case_select].__class__):
                x = 412.416
                y = 252.828
                img1 = pg.transform.scale(self.jeu.img_inv_degat_1, (4, 7))
                img2 = pg.transform.scale(self.jeu.img_inv_degat_3, (4, 7))
                img3 = pg.transform.scale(self.jeu.img_inv_degat_2, (4, 7))
                for i in range(0, self.inventaire[self.case_select].degat, 3):
                    if i == 0:
                        self.jeu.ecran.blit(img1, (x, y))
                    elif i == 99:
                        self.jeu.ecran.blit(img2, (x, y))
                    else:
                        self.jeu.ecran.blit(img3, (x, y))
                    x += 3
                if self.inventaire[self.case_select].effet == 'feu':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_feu, (420, 277))
                elif self.inventaire[self.case_select].effet == 'glace':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_glace, (420, 277))
                elif self.inventaire[self.case_select].effet == 'foudre':
                    self.jeu.ecran.blit(self.jeu.img_inv_logo_foudre, (420, 277))



        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic :
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            originX = 611
            originY = 164
            if originX < x < originX + 4 * 60.4 and originY < y < originY + 6*60.4:
                X = (x - originX) // 60.4
                Y = (y - originY) // 60.4
                numeroCase = 4 * Y + X
                nomCase = 'case'+str(int(numeroCase))
                if self.inventaire[nomCase] is not None:
                    self.case_select = nomCase
            elif 206.715 - 5 < x < 206.715 + 60.4 and 143.035 - 5 < y < 143.035 + 60.4:
                if self.inventaire['armure'] is not None:
                    self.case_select = 'armure'
                    self.resistance = self.inventaire['armure'].resistance
            elif 333.558 - 5 < x < 333.558 + 60.4 and 143.035 - 5 < y < 143.035 + 60.4:
                if self.inventaire['arme'] is not None:
                    self.case_select = 'arme'
            elif 209.113 - 5 < x < 209.113 + 60.4 and 267.292 - 5 < y < 267.292 + 60.4:
                if self.inventaire['potion'] is not None:
                    self.case_select = 'potion'
           # bouton +
            elif 538.591 < x < 538.591 + 17.601 and 156.136 < y < 156.136 + 17.601 and self.case_select != '':
                enTransite = self.inventaire[self.case_select]
                if "<class 'items.Potion'>" == str(enTransite.__class__) :
                    self.inventaire[self.case_select] = self.inventaire['potion']
                    self.inventaire['potion'] = enTransite
                elif "<class 'items.Arme'>" == str(enTransite.__class__):
                    self.inventaire[self.case_select] = self.inventaire['arme']
                    self.inventaire['arme'] = enTransite
                    self.degat = self.inventaire['arme'].degat
                elif "<class 'items.Armure'>" == str(enTransite.__class__):
                    self.inventaire[self.case_select] = self.inventaire['armure']
                    self.inventaire['armure'] = enTransite
                self.case_select = ''
                self.infoOuvert = False
            # bouton supprimer
            elif 538.232 < x < 538.232 + 18.319 and 216.572 < y < 216.572 + 18.319 and self.case_select != '':
                if "case" in self.case_select:
                    self.inventaire[self.case_select] = None
                else:
                    self.ajouter_dans_inventaire(self.inventaire[self.case_select])
                    self.inventaire[self.case_select] = None
                    self.case_select = ''
                    if self.inventaire['arme'] == None:
                        self.degat = 0
                self.infoOuvert = False
            # bouton info
            elif 538.555 < x < 538.555 + 17.673 and 186.497 < y < 186.497 + 17.673 and self.case_select != '':
                self.infoOuvert = not self.infoOuvert

    def ajouter_dans_inventaire(self, objet):
        for indice, item in self.inventaire.items():
            if "case" in indice and item is None:
                self.inventaire[indice] = objet
                break

    def retirer_de_inventaire(self, objet):
        for indice, item in self.inventaire.items():
            if "case" in indice and item is not None:
                if item.nom == objet:
                    self.inventaire[indice] = None
            break

    def inventaire_plein(self):
        nb = 0
        for indice,item in self.inventaire.items():
            if "case" in indice and item is not None:
                nb += 1
        if nb == 24:
            return True
        else:
            return False

    def est_dans_inventaire(self, object):
        for indice, item in self.inventaire.items():
            if "case" in indice and item is not None:
                if item.nom == object:
                    return True
        return False

    def est_dans_zone_mob(self, mobs):
        for mob in mobs:
            if self.rect.colliderect(mob.zoneDetect):
                mob.agro = True
            else:
                mob.agro = False


class Armurier(pg.sprite.Sprite):
    def __init__(self, jeu, metier, x, y, img):
        self._layer = PLAYER_LAYER
        self.jeu = jeu
        self.groups = jeu.all_sprites, jeu.pnj
        pg.sprite.Sprite.__init__(self, self.groups)
        self.metier = metier
        self.x = x
        self.y = y
        self.hitbox = pg.Rect(x-4*64, y-4*64, 8*64, 8*64)
        # self.rect = self.hitbox
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.topleft = (x, y)
        self.image = img
        self.inventaire = {'armure_1': Armure(self.jeu.img_armure_1, 5, 'Armure de voyageur', 200),
                           'armure_2': Armure(self.jeu.img_armure_2, 7, 'Armure de chevalier', 400),
                           'armure_3': Armure(self.jeu.img_armure_3, 10, 'Armure légendaire', 1200),
                           'katana_1': Arme(self.jeu.img_katana_1, 25, 'katana', 'Katana de voyageur', 200),
                           'katana_2': Arme(self.jeu.img_katana_2, 35, 'katana', 'Katana de chevalier', 400),
                           'katana_3': Arme(self.jeu.img_katana_3, 100, 'katana', 'Katana légendaire', 2000, 'feu'),
                            'arc_1': Arme(self.jeu.img_arc_1, 20, 'arc', 'Arc de voyageur', 100),
                           'arc_2': Arme(self.jeu.img_arc_2, 30, 'arc', 'Arc de chevalier', 400),
                           'arc_3': Arme(self.jeu.img_arc_3, 150, 'arc', 'Arc légendaire', 2000, 'glace'),
                            'marteau_1': Arme(self.jeu.img_marteau_1, 35, 'marteau', 'Marteau de voyageur', 250),
                           'marteau_2': Arme(self.jeu.img_marteau_2, 50, 'marteau', 'Marteau de chevalier', 500),
                           'marteau_3': Arme(self.jeu.img_marteau_3, 200, 'marteau', 'Marteau légendaire', 3000, 'foudre')}
        self.etape_boutique = 1  # 1,2ou3
        self.rangs_boutique = ['armure_', 'katana_', 'marteau_', 'arc_']
        self.rang_clique = False
        self.rang_select = - 1
        self.itemClique = None
        self.dialogue = "Salut Ulyce ça fait longtemps ! Qu'est ce que je"
        self.dialogue2 = "peux faire pour toi ?"
        self.boutiqueOuverte = False
        self.itemAchete = []

    def afficher_boutique(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_boutique_armurier, (494.061, 238.924))
        # partie gauche
        x_img = 521.833 + 7
        y_img = 263.177
        x_rang = 513.586 + 7
        y_rang = 256.767
        x_nom = 580.312 + 7
        y_nom = 266.812
        x_prix = 694.734 + 7
        y_prix = 289.649
        for i in range(4):
            y_img = 263.177 + 64 * i
            y_rang = 256.767 + 64 * i
            y_nom = 266.812 + 64 * i
            y_prix = 289.649 + 64 * i
            nom_item = self.rangs_boutique[i] + str(self.etape_boutique)
            item = self.inventaire[nom_item]
            if item.clique:
                self.jeu.ecran.blit(self.jeu.img_rang_select, (x_rang, y_rang))
            self.jeu.ecran.blit(item.img, (x_img, y_img))
            self.jeu.draw_text(item.nom, self.jeu.font_ecriture, 12, [0, 0, 0], x_nom, y_nom)
            self.jeu.draw_text(str(item.prix)+'$', self.jeu.font_ecriture, 11, [0, 0, 0], x_prix, y_prix)
        # partie droite
        x_nom = 840.094 + 7
        y_nom = 254.027
        x_img = 848.874 + 7
        y_img = 294.719
        x_logo = 924.684 + 7
        y_logo = 324
        x_prix = 941.194 + 7
        y_prix = 488.492
        for indice, item in self.inventaire.items():
            if item.clique:
                if item.effet is not None:
                    if item.effet == 'foudre':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_foudre, (x_logo, y_logo))
                    elif item.effet == 'feu':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_feu, (x_logo, y_logo))
                    elif item.effet == 'glace':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_glace, (x_logo, y_logo))
                image = pg.transform.scale(item.img, (64, 64))
                self.jeu.ecran.blit(image, (x_img, y_img))
                self.jeu.draw_text(item.nom, self.jeu.font_ecriture, 12, [0, 0, 0], x_nom, y_nom)
                self.jeu.draw_text(str(item.prix)+'$', self.jeu.font_ecriture, 11, [0, 0, 0], x_prix, y_prix)
                if item in self.itemAchete:
                    self.jeu.draw_text('Acheté', self.jeu.font_ecriture, 16, [49, 240, 34], x_prix - 90, y_prix - 30)
                if "<class 'items.Arme'>" == str(item.__class__):
                    x = 850.538 + 7
                    y = 383.465
                    img1 = pg.transform.scale(self.jeu.img_inv_degat_1, (5, 8))
                    img2 = pg.transform.scale(self.jeu.img_inv_degat_3, (5, 8))
                    img3 = pg.transform.scale(self.jeu.img_inv_degat_2, (5, 8))
                    for i in range(0, item.degat, 3):
                        if i == 0:
                            self.jeu.ecran.blit(img1, (x, y))
                        elif i == 99:
                            self.jeu.ecran.blit(img2, (x, y))
                        else:
                            self.jeu.ecran.blit(img3, (x, y))
                        x += 3
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 513.068 < x < 513.068+255.867 and 256.78 < y < 256.78+60.757:
                self.rang_select = 0
            elif 513.068 < x < 513.068+255.867 and 320.83 < y < 320.83+60.757:
                self.rang_select = 1
            elif 513.068 < x < 513.068+255.867 and 385.879 < y < 385.879+60.757:
                self.rang_select = 2
            elif 513.068 < x < 513.068+255.867 and 450.181 < y < 450.181+60.757:
                self.rang_select = 3
            if self.rang_select != - 1:
                if self.itemClique is not None:
                    self.itemClique.clique = False
                nom_item = self.rangs_boutique[self.rang_select] + str(self.etape_boutique)
                self.inventaire[nom_item].clique = not self.inventaire[nom_item].clique
                self.rang_select = - 1
                self.rang_clique = self.inventaire[nom_item].clique
                if self.rang_clique:
                    self.itemClique = self.inventaire[nom_item]
                else:
                    self.itemClique = None
            # fleches
            if 786.725 < x < 786.725 + 25.202 and 256.402 < y < 256.402 + 24.867:
                if self.etape_boutique > 1:
                    self.etape_boutique -= 1
            elif 786.725 < x < 786.725 + 25.202 and 486.875 < y < 486.875 + 24.867:
                if self.etape_boutique < 3:
                    self.etape_boutique += 1
            # acheter
            if 910 < x < 910 + 25 and 480 < y < 480 + 25 and self.rang_clique:
                if self.itemClique.prix <= self.jeu.player.argent:
                    self.jeu.player.argent -= self.itemClique.prix
                    self.jeu.player.ajouter_dans_inventaire(self.itemClique)
                    self.itemAchete.append(self.itemClique)

    def afficher_dialogue(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_barre_dialogue, (486.568, 535.104))
        # texte
        self.jeu.draw_text(self.dialogue, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 560.5)
        self.jeu.draw_text(self.dialogue2, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 584.5)
        self.jeu.draw_text('- Acheter', self.jeu.font_ecriture, 14, [0, 0, 0], 779, 596.5)
        self.jeu.draw_text('- Quitter', self.jeu.font_ecriture, 14, [0, 0, 0], 903.142, 596.5)
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 779 < x < 779+83 and 596.5 < y < 596.5+19:
                self.boutiqueOuverte = True
            elif 903.142 < x < 903.142+75 and 596.5 < y < 596.5+19:
                self.jeu.dialogueEnCours = False
                self.boutiqueOuverte = False


class Sorcier(pg.sprite.Sprite):
    def __init__(self, jeu, metier, x, y, img):
        self._layer = PLAYER_LAYER
        self.jeu = jeu
        self.groups = jeu.all_sprites, jeu.pnj
        pg.sprite.Sprite.__init__(self, self.groups)
        self.metier = metier
        self.x = x
        self.y = y
        self.hitbox = pg.Rect(x-4*64, y-4*64, 8*64, 8*64)
        # self.rect = self.hitbox
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.topleft = (x, y)
        self.image = img
        self.inventaire = {'potion_0': Potion(self.jeu, self.jeu.img_potion_vitesse, 'vitesse', 'Potion de vitesse', 100),
                           'potion_1': Potion(self.jeu, self.jeu.img_potion_vie, 'vie', 'Potion de vie', 100),
                           'potion_2': Potion(self.jeu, self.jeu.img_potion_degat, 'degat', 'Potion de degat', 75)}
        self.rang_clique = False
        self.rang_select = - 1
        self.itemClique = None
        self.dialogue = "Salut Ulyce ça fait longtemps ! Qu'est ce que je"
        self.dialogue2 = "peux faire pour toi ?"
        # self.dialogueRencontre = "Bienvenue! Tu dois être le fameux Ulyce. Je suis ... l'armurier! Qu'est ce que je peux faire pour toi ?"
        self.boutiqueOuverte = False
        self.itemAchete = []

    def afficher_boutique(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_boutique_armurier, (494.061, 238.924))
        self.jeu.ecran.blit(self.jeu.img_cache_rang, (516, 450))
        # partie gauche
        x_img = 521.833 + 7
        y_img = 263.177
        x_rang = 513.586 + 7
        y_rang = 256.767
        x_nom = 580.312 + 7
        y_nom = 266.812
        x_prix = 694.734 + 7
        y_prix = 289.649
        for i in range(3):
            y_img = 263.177 + 64 * i
            y_rang = 256.767 + 64 * i
            y_nom = 266.812 + 64 * i
            y_prix = 289.649 + 64 * i
            nom_item = 'potion_' + str(i)
            item = self.inventaire[nom_item]
            if item.clique:
                self.jeu.ecran.blit(self.jeu.img_rang_select, (x_rang, y_rang))
            self.jeu.ecran.blit(item.img, (x_img, y_img))
            self.jeu.draw_text(item.nom, self.jeu.font_ecriture, 12, [0, 0, 0], x_nom, y_nom)
            self.jeu.draw_text(str(item.prix)+'$', self.jeu.font_ecriture, 11, [0, 0, 0], x_prix, y_prix)
        # partie droite
        x_nom = 840.094 + 7
        y_nom = 254.027
        x_img = 848.874 + 7
        y_img = 294.719
        x_logo = 924.684 + 7
        y_logo = 324
        x_prix = 941.194 + 7
        y_prix = 488.492
        for indice, item in self.inventaire.items():
            if item.clique:
                if item.type is not None:
                    if item.type == 'vie':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_vie, (x_logo, y_logo))
                    elif item.type == 'vitesse':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_vitesse, (x_logo, y_logo))
                    elif item.type == 'degat':
                        self.jeu.ecran.blit(self.jeu.img_inv_logo_degat, (x_logo, y_logo))
                image = pg.transform.scale(item.img, (64, 64))
                self.jeu.ecran.blit(image, (x_img, y_img))
                self.jeu.draw_text(item.nom, self.jeu.font_ecriture, 12, [0, 0, 0], x_nom, y_nom)
                self.jeu.draw_text(str(item.prix)+'$', self.jeu.font_ecriture, 11, [0, 0, 0], x_prix, y_prix)
                if item in self.itemAchete:
                    self.jeu.draw_text('Acheté', self.jeu.font_ecriture, 16, [49, 240, 34], x_prix - 90, y_prix - 30)
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 513.068 < x < 513.068+255.867 and 256.78 < y < 256.78+60.757:
                self.rang_select = 0
            elif 513.068 < x < 513.068+255.867 and 320.83 < y < 320.83+60.757:
                self.rang_select = 1
            elif 513.068 < x < 513.068+255.867 and 385.879 < y < 385.879+60.757:
                self.rang_select = 2
            if self.rang_select != - 1:
                if self.itemClique is not None:
                    self.itemClique.clique = False
                nom_item = 'potion_' + str(self.rang_select)
                self.inventaire[nom_item].clique = not self.inventaire[nom_item].clique
                self.rang_select = - 1
                self.rang_clique = self.inventaire[nom_item].clique
                if self.rang_clique:
                    self.itemClique = self.inventaire[nom_item]
                else:
                    self.itemClique = None
            # acheter
            if 910 < x < 910 + 25 and 480 < y < 480 + 25 and self.rang_clique:
                if self.itemClique.prix < self.jeu.player.argent:
                    self.jeu.player.argent -= self.itemClique.prix
                    self.jeu.player.ajouter_dans_inventaire(self.itemClique)
                    self.itemAchete.append(self.itemClique)

    def afficher_dialogue(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_barre_dialogue, (486.568, 535.104))
        # texte
        self.jeu.draw_text(self.dialogue, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 560.5)
        self.jeu.draw_text(self.dialogue2, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 584.5)
        self.jeu.draw_text('- Acheter', self.jeu.font_ecriture, 14, [0, 0, 0], 779, 596.5)
        self.jeu.draw_text('- Quitter', self.jeu.font_ecriture, 14, [0, 0, 0], 903.142, 596.5)
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 779 < x < 779+83 and 596.5 < y < 596.5+19:
                self.boutiqueOuverte = True
            elif 903.142 < x < 903.142+75 and 596.5 < y < 596.5+19:
                self.jeu.dialogueEnCours = False
                self.boutiqueOuverte = False


class Aubergiste(pg.sprite.Sprite):
    def __init__(self, jeu, metier, x, y, img):
        self._layer = PLAYER_LAYER
        self.jeu = jeu
        self.groups = jeu.all_sprites, jeu.pnj
        pg.sprite.Sprite.__init__(self, self.groups)
        self.metier = metier
        self.x = x
        self.y = y
        self.hitbox = pg.Rect(x - 4 * 64, y - 4 * 64, 8 * 64, 8 * 64)
        # self.rect = self.hitbox
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.topleft = (x, y)
        self.image = img
        self.dialogue = "Salut Ulyce ça fait longtemps ! Tu tombe bien, j'ai"
        self.dialogue2 = "une nouvelle quête pour toi."
        self.dialogue3 = "Bravo! J'ai appris que tu avait complété ta quete."
        self.dialogue4 = "Voilà ta récompense bien mérité!"
        self.dialogue5 = "Bah alors. Qu'est ce que tu fais encore là ?"
        self.dialogue6 = "Tu as une quete qui t'attend je te rappel."
        self.boutiqueOuverte = False
        self.quete1 = self.jeu.quete1
        self.quete2 = self.jeu.quete2
        self.quete3 = self.jeu.quete3
        self.quete4 = self.jeu.quete4
        self.queteActuel = self.quete1

    def afficher_dialogue(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_barre_dialogue, (486.568, 535.104))
        # texte
        if self.jeu.player.queteEnCours is None:
            self.jeu.draw_text(self.dialogue, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 560.5)
            self.jeu.draw_text(self.dialogue2, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 584.5)
            self.jeu.draw_text('- Continuer', self.jeu.font_ecriture, 14, [0, 0, 0], 779, 596.5)
        elif self.jeu.player.queteTermine:
            self.jeu.draw_text(self.dialogue3, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 560.5)
            self.jeu.draw_text(self.dialogue4, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 584.5)

            self.jeu.player.xp += self.jeu.player.queteEnCours['recompenseInt']['xp']
            self.jeu.player.argent += self.jeu.player.queteEnCours['recompenseInt']['or']
            if self.jeu.player.queteEnCours == self.quete1:
                self.queteActuel = self.quete2
            if self.jeu.player.queteEnCours == self.quete2:
                self.queteActuel = self.quete3
            if self.jeu.player.queteEnCours == self.quete3:
                self.queteActuel = self.quete4
            self.jeu.player.queteEnCours = None
        elif not self.jeu.player.queteTermine:
            self.jeu.draw_text(self.dialogue5, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 560.5)
            self.jeu.draw_text(self.dialogue6, self.jeu.font_ecriture, 14, [0, 0, 0], 530.176, 584.5)
        self.jeu.draw_text('- Quitter', self.jeu.font_ecriture, 14, [0, 0, 0], 903.142, 596.5)
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 779 < x < 779 + 83 and 596.5 < y < 596.5 + 19:
                self.boutiqueOuverte = True
            elif 903.142 < x < 903.142 + 75 and 596.5 < y < 596.5 + 19:
                self.jeu.dialogueEnCours = False
                self.boutiqueOuverte = False

    def afficher_boutique(self):
        # fond
        self.jeu.ecran.blit(self.jeu.img_fond_quete, (552, 312))
        # texte
        x = 574
        y = 332
        for ligne in self.queteActuel['texte']:
            self.jeu.draw_text(ligne, self.jeu.font_ecriture, 13, [0, 0, 0], x, y)
            y += 20
        y = 431
        for ligne in self.queteActuel['recompense']:
            self.jeu.draw_text(ligne, self.jeu.font_ecriture, 14, [0, 0, 0], x, y)
            y += 20
        # boutons
        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 841 < x < 841 + 40 and 495 < y < 495 + 40:
                self.jeu.player.queteEnCours = self.queteActuel
                self.jeu.player.queteTermine = False
                self.jeu.dialogueEnCours = False
                self.boutiqueOuverte = False
            elif 895 < x < 895 + 40 and 495 < y < 495 + 40:
                self.jeu.dialogueEnCours = False
                self.boutiqueOuverte = False













