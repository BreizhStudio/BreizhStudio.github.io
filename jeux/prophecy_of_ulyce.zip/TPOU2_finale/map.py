from constantes import *
import pygame as pg
import pytmx

from os import path


class Map:
    def __init__(self,jeu, fichier):
        myMap = pytmx.load_pygame(fichier, pixelalpha=True)
        self.width = myMap.width * myMap.tilewidth
        self.height = myMap.height * myMap.tileheight
        self.tmxdata = myMap
        self.rect = 0
        self.jeu = jeu

    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid, in layer:
                    tile = ti(gid)
                    if tile:
                        surface.blit(tile, (x * self.tmxdata.tilewidth, y * self.tmxdata.tileheight))


    def make_map(self):
        temp_surface = pg.Surface((self.width, self.height))
        self.render(temp_surface)
        return temp_surface


class Camera:
    def __init__(self, longueur, largeur):
        self.camera = pg.Rect(0, 0, longueur, largeur)
        self.width = longueur
        self.height = largeur

    def aligner(self, object):
        return object.rect.move(self.camera.topleft)

    def aligner_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, object):
        x = -object.rect.centerx + int(FENETRE_LONGUEUR / 2)
        y = -object.rect.centery + int(FENETRE_LARGEUR / 2)

        # limite bord de la map
        x = min(0, x)  # gauche
        y = min(0, y)  # haut
        x = max(-(self.width - FENETRE_LONGUEUR), x)  # droite
        y = max(-(self.height - FENETRE_LARGEUR), y)  # bas
        self.camera = pg.Rect(x, y, self.width, self.height)


class Obstacle(pg.sprite.Sprite):
    def __init__(self, game, x, y, L, l):
        self.groups = game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, L, l)
        self.hitbox = self.rect  # hit_rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y


class Porte(pg.sprite.Sprite):
    def __init__(self, game, x, y, L, l, nom):
        self.groups = game.portes
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, L, l)
        self.hitbox = self.rect  # hit_rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y
        self.name = nom


class Spawn(pg.sprite.Sprite):
    def __init__(self, game, x, y, L, l, nom):
        self.groups = game.spawns
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, L, l)
        self.hitbox = self.rect  # hit_rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y
        self.name = nom


class Grille(pg.sprite.Sprite):
    def __init__(self, game, x, y, L, l):
        self.groups = game.grilles
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, L, l)
        self.hitbox = self.rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y
        self.ouvert = False


class Teleportation(pg.sprite.Sprite):
    def __init__(self, game, x, y, L, l, nom):
        self.groups = game.teleports
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, L, l)
        self.hitbox = self.rect  # hit_rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y
        self.name = nom


if __name__ == '__main__':
    dossier_jeu = path.dirname(__file__)  # game_folder
    dossier_maps = path.join(dossier_jeu, 'maps')

    pg.init()
    screen = pg.display.set_mode((FENETRE_LONGUEUR, FENETRE_LARGEUR))

    myMap = Map(path.join(dossier_maps, 'interieur_armurier_csv.tmx'))
    map_img = myMap.make_map()
    myMap.rect = map_img.get_rect()
    camera = Camera(myMap.width, myMap.height)


    while True:
        screen.blit(map_img, camera.aligner(myMap))
        pg.display.flip()