import pygame as pg
from constantes import *
from items import *
from math import sqrt, acos
vec = pg.math.Vector2


class Mob(pg.sprite.Sprite):
    def __init__(self, jeu, x, y, image):
        self._layer = MOB_LAYER
        self.groups = jeu.all_sprites, jeu.mobs
        pg.sprite.Sprite.__init__(self, self.groups)
        self.jeu = jeu
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.center = (x, y)
        self.hitbox = PLAYER_HITBOX
        self.hitbox.center = self.rect.center
        self.vitesseX = 0
        self.vitesseY = 0
        self.vitesse = 0.5
        self.x = x
        self.y = y
        self.direction = "DROITE"
        self.vie = 100
        self.vieOrigin = 100
        self.degat = 15
        self.image = image
        self.target = jeu.player
        self.pas = 1
        self.depuisPas = 0
        self.zoneDetect = pg.Rect(0, 0, 64*7, 64*7)
        self.zoneDetect.center = self.rect.center
        self.agro = False
        self.repos = 0
        self.health_bar = None

    def update(self):
        self.jeu.player.est_dans_zone_mob(self.jeu.mobs)
        if self.agro and pg.time.get_ticks() - self.repos > 500:
            vX = int(self.jeu.player.x - self.x)
            vY = int(self.jeu.player.y - self.y)
            if abs(vX) >= abs(vY):
                if vX < 0:
                    self.vitesseX = - self.vitesse
                    self.direction = 'GAUCHE'
                elif vX > 0:
                    self.vitesseX = self.vitesse
                    self.direction = 'DROITE'
                self.vitesseY = 0
            else:
                if vY < 0:
                    self.vitesseY = - self.vitesse
                    self.direction = 'HAUT'
                elif vY > 0:
                    self.vitesseY = self.vitesse
                    self.direction = 'BAS'
                self.vitesseX = 0
        else:
            self.vitesseX = 0
            self.vitesseY = 0

        if self.vie <= 0:
            self.kill()

        self.x += self.vitesseX
        if not self.rect.width / 2 < self.x < self.jeu.map.width - self.rect.width / 2:
            self.x -= self.vitesseX

        self.y += self.vitesseY
        if not self.rect.height / 2 < self.y < self.jeu.map.height - self.rect.height / 2:
            self.y -= self.vitesseY

        self.rect.center = (self.x, self.y)
        self.hitbox.center = self.rect.center
        self.zoneDetect.center = self.rect.center


        if self.vitesseX != 0:
            self.jeu.collide_with_walls(self, self.jeu.walls, 'x')
        if self.vitesseY != 0:
            self.jeu.collide_with_walls(self, self.jeu.walls, 'y')

        if self.direction == 'DROITE':
            if self.vitesseX == 0:
                self.image = self.jeu.img_mob_droite_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_mob_droite_1
                if self.pas == 2:
                    self.image = self.jeu.img_mob_droite_2
                if self.pas == 3:
                    self.image = self.jeu.img_mob_droite_3
        if self.direction == 'GAUCHE':
            if self.vitesseX == 0:
                self.image = self.jeu.img_mob_gauche_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_mob_gauche_1
                if self.pas == 2:
                    self.image = self.jeu.img_mob_gauche_2
                if self.pas == 3:
                    self.image = self.jeu.img_mob_gauche_3
        if self.direction == 'BAS':
            if self.vitesseY == 0:
                self.image = self.jeu.img_mob_face_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_mob_face_1
                if self.pas == 2:
                    self.image = self.jeu.img_mob_face_2
                if self.pas == 3:
                    self.image = self.jeu.img_mob_face_3
        if self.direction == 'HAUT':
            if self.vitesseY == 0:
                self.image = self.jeu.img_mob_dos_2
            else:
                if self.pas == 1:
                    self.image = self.jeu.img_mob_dos_1
                if self.pas == 2:
                    self.image = self.jeu.img_mob_dos_2
                if self.pas == 3:
                    self.image = self.jeu.img_mob_dos_3
        if self.depuisPas == 70:
            if self.pas == 3:
                self.pas = 1
            else:
                self.pas += 1
            self.depuisPas = 0
        self.depuisPas += 1
        # self.draw_health()

    def draw_health(self):
        if self.vie > 60:
            col = [0, 255, 0]
        elif self.vie > 30:
            col = [255, 255, 0]
        else:
            col = [255, 0, 0]
        width = int(self.rect.width * self.vie / self.vieOrigin)
        self.health_bar = pg.Rect(0, 0, width, 7)
        if self.vie < self.vieOrigin:
            pg.draw.rect(self.image, col, self.health_bar)


class Dragon(pg.sprite.Sprite):
    def __init__(self, jeu, x, y):
        self._layer = MOB_LAYER
        self.groups = jeu.all_sprites, jeu.mobs
        pg.sprite.Sprite.__init__(self, self.groups)
        self.jeu = jeu
        self.rect = pg.Rect(0, 0, 64, 64)
        self.rect.center = (x, y)
        self.hitbox = PLAYER_HITBOX
        self.hitbox.center = self.rect.center
        self.x = x
        self.y = y
        self.direction = "DROITE"
        self.vieOrigin = 75
        self.vie = 75
        self.degat = 10
        self.image = self.jeu.img_dragon_face

        self.zoneDetect = pg.Rect(0, 0, 64*7, 64*7)
        self.zoneDetect.center = self.rect.center
        self.agro = False
        self.last_shot = 0
        self.health_bar = None

        self.vitesse_projectile = 1

    def update(self):
        self.jeu.player.est_dans_zone_mob(self.jeu.mobs)
        if self.agro and pg.time.get_ticks() - self.last_shot > 1000:
            vX = int(self.jeu.player.x - self.x)
            vY = int(self.jeu.player.y - self.y)
            vecMobPlayer = vec(vX, vY)
            rot = vecMobPlayer.angle_to(vec(1, 0))
            img_shoot = self.jeu.img_boule_feu
            if 45 < rot < 135:
                self.image = self.jeu.img_dragon_dos
                self.direction = 'HAUT'
            elif 135 < rot or rot < -135:
                self.image = self.jeu.img_dragon_gauche
                self.direction = 'GAUCHE'
            elif -135 < rot < -45:
                self.image = self.jeu.img_dragon_face
                self.direction = 'BAS'
            elif -45 < rot < 45:
                self.image = self.jeu.img_dragon_droite
                self.direction = 'DROITE'
            self.last_shot = pg.time.get_ticks()
            rot = vecMobPlayer.angle_to(vec(1, 0))
            if vecMobPlayer.x != 0:
                vecMobPlayer.y = (vecMobPlayer.y / abs(vecMobPlayer.x)) * 0.5
                vecMobPlayer.x = (vecMobPlayer.x / abs(vecMobPlayer.x)) * 0.5
            else:
                vecMobPlayer.y = (vecMobPlayer.y / abs(vecMobPlayer.y)) * 0.5
            self.last_shot = pg.time.get_ticks()
            img_shoot = pg.transform.rotate(img_shoot, rot)
            Projectile(self.jeu, self.rect.centerx, self.rect.centery, vecMobPlayer, self.degat, img_shoot,
                       self.vitesse_projectile, self)

        if self.vie <= 0:
            self.kill()
        # self.draw_health()

    def draw_health(self):
        if self.vie > 30:
            col = [0, 255, 0]
        elif self.vie > 15:
            col = [255, 255, 0]
        else:
            col = [255, 0, 0]
        width = int(self.rect.width * self.vie / self.vieOrigin)
        self.health_bar = pg.Rect(0, 0, width, 7)
        if self.vie < self.vieOrigin:
            pg.draw.rect(self.image, col, self.health_bar)


class Boss(pg.sprite.Sprite):
    def __init__(self, jeu, x, y, niveau):
        self._layer = MOB_LAYER
        self.groups = jeu.all_sprites, jeu.mobs
        pg.sprite.Sprite.__init__(self, self.groups)
        self.jeu = jeu
        self.image = self.jeu.img_boss_droite
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.hitbox = self.image.get_rect()
        self.hitbox.center = self.rect.center
        self.x = x
        self.y = y
        self.direction = "DROITE"
        self.degatBoule = 20
        self.degatOrbe = 30
        self.niveau = niveau
        if niveau == 1:
            self.vieOrigin = 500
        elif niveau == 2:
            self.vieOrigin = 1500
        elif niveau == 3:
            self.vieOrigin = 3000
        self.vie = self.vieOrigin

        self.zoneDetect = pg.Rect(0, 0, 64*17, 64*17)
        self.zoneDetect.center = self.rect.center
        self.agro = False
        self.last_shot = 0
        self.health_bar = None

        self.vitesse_boule = 0.75
        self.vitesse_orbe = 1
        self.nbAttaque = 1

    def update(self):
        self.jeu.player.est_dans_zone_mob(self.jeu.mobs)
        if self.agro and pg.time.get_ticks() - self.last_shot > 2000:
            vX = int(self.jeu.player.x - self.x)
            vY = int(self.jeu.player.y - self.y)
            vecMobPlayer = vec(vX, vY)
            rot = vecMobPlayer.angle_to(vec(1, 0))
            if -90 < rot < 90:
                self.image = self.jeu.img_boss_droite
            else:
                self.image = self.jeu.img_boss_gauche
            if vecMobPlayer.x != 0:
                vecMobPlayer.y = (vecMobPlayer.y / abs(vecMobPlayer.x))*0.5
                vecMobPlayer.x = (vecMobPlayer.x / abs(vecMobPlayer.x))*0.5
            else:
                vecMobPlayer.y = (vecMobPlayer.y / abs(vecMobPlayer.y)) * 0.5
            self.last_shot = pg.time.get_ticks()
            img_shoot_bouleFeu = self.jeu.img_boule_feu
            img_shoot_orbeMagique = self.jeu.img_orbe_magique
            img_shoot_bouleFeu = pg.transform.rotate(img_shoot_bouleFeu, rot)
            if self.niveau == 1:
                Projectile(self.jeu, self.rect.centerx + 10, self.rect.centery, vecMobPlayer, self.degatBoule,
                           img_shoot_bouleFeu, self.vitesse_boule, self)
                Projectile(self.jeu, self.rect.centerx - 10, self.rect.centery, vecMobPlayer, self.degatBoule,
                           img_shoot_bouleFeu, self.vitesse_boule, self)
            elif self.niveau == 2:
                Projectile(self.jeu, self.rect.centerx + 40, self.rect.centery, vecMobPlayer, self.degatBoule,
                           img_shoot_bouleFeu, self.vitesse_boule, self)
                Projectile(self.jeu, self.rect.centerx - 40, self.rect.centery, vecMobPlayer, self.degatBoule,
                           img_shoot_bouleFeu, self.vitesse_boule, self)
                Projectile(self.jeu, self.rect.centerx, self.rect.centery, vecMobPlayer, self.degatOrbe,
                           img_shoot_orbeMagique, self.vitesse_orbe, self)
            elif self.niveau == 3:
                if self.nbAttaque % 2 == 0:
                    Projectile(self.jeu, self.rect.centerx + 60, self.rect.centery, vecMobPlayer, self.degatOrbe,
                               img_shoot_orbeMagique, self.vitesse_orbe, self)
                    Projectile(self.jeu, self.rect.centerx - 60, self.rect.centery, vecMobPlayer, self.degatOrbe,
                               img_shoot_orbeMagique, self.vitesse_orbe, self)
                    Projectile(self.jeu, self.rect.centerx, self.rect.centery, vecMobPlayer, self.degatOrbe,
                               img_shoot_orbeMagique, self.vitesse_orbe, self)
                else:
                    Projectile(self.jeu, self.rect.centerx + 60, self.rect.centery, vecMobPlayer, self.degatBoule,
                               img_shoot_bouleFeu, self.vitesse_boule, self)
                    Projectile(self.jeu, self.rect.centerx - 60, self.rect.centery, vecMobPlayer, self.degatBoule,
                               img_shoot_bouleFeu, self.vitesse_boule, self)
                    Projectile(self.jeu, self.rect.centerx + 20, self.rect.centery, vecMobPlayer, self.degatBoule,
                               img_shoot_bouleFeu, self.vitesse_boule, self)
                    Projectile(self.jeu, self.rect.centerx - 20, self.rect.centery, vecMobPlayer, self.degatBoule,
                               img_shoot_bouleFeu, self.vitesse_boule, self)
                self.nbAttaque += 1

        if self.vie <= 0:
            self.kill()

        self.draw_health()

    def draw_health(self):
        if self.vie > self.vieOrigin//3 * 2:
            col = [0, 255, 0]
        elif self.vie > self.vieOrigin//3:
            col = [255, 255, 0]
        else:
            col = [255, 0, 0]
        width = int(self.rect.width * self.vie / self.vieOrigin)
        self.health_bar = pg.Rect(0, 0, width, 7)
        if self.vie < self.vieOrigin:
            pg.draw.rect(self.image, col, self.health_bar)



