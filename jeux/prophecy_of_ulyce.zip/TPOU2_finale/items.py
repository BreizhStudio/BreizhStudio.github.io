import pygame as pg
from random import randint
from constantes import *
vec = pg.math.Vector2


class Projectile(pg.sprite.Sprite):
    def __init__(self, jeu, x, y, dir, degat, img, vitesse, tireur):
        self._layer = BULLET_LAYER
        self.groups = jeu.all_sprites, jeu.projectiles
        pg.sprite.Sprite.__init__(self, self.groups)
        self.jeu = jeu
        self.image = img
        self.rect = self.image.get_rect()
        self.hitbox = self.rect
        self.x = x
        self.y = y
        self.rect.center = (x, y)
        self.dir = dir
        self.vitesse = vitesse
        self.vecVitesse = vec(self.dir.x, self.dir.y)
        self.spawn_time = pg.time.get_ticks()
        self.degat = degat

        self.lifetime = 9000
        self.tireur = tireur

    def update(self):
        self.x += self.vecVitesse.x
        self.y += self.vecVitesse.y

        self.rect.center = (self.x, self.y)
        if pg.sprite.spritecollideany(self, self.jeu.walls):
            self.kill()
        if pg.time.get_ticks() - self.spawn_time > self.lifetime:
            self.kill()

        hits = pg.sprite.spritecollide(self, self.jeu.mobs, False)
        if hits and self.tireur == self.jeu.player:
            hits[0].vie -= self.degat
            self.kill()
        if self.rect.colliderect(self.jeu.player.rect) and self.tireur != self.jeu.player:
            self.jeu.player.vie -= self.degat
            self.kill()


class Item:
    def __init__(self, img, nom=None, prix=None):
        self.img = img
        self.clique = False
        self.nom = nom
        self.prix = prix


class Arme(Item):
    def __init__(self, img, degat, type, nom=None, prix=None, effet = None):
        super().__init__(img, nom, prix)
        self.degat = degat
        self.type = type
        self.effet = effet
        if self.type == 'katana':
            self.rate = 500
        elif self.type == 'marteau':
            self.rate = 1000
        elif self.type == 'arc':
            self.rate = 500
            self.vitesse_projectile = 2.5


class Armure(Item):
    def __init__(self, img, resistance, nom=None, prix=None, effet = None):
        super().__init__(img, nom, prix)
        self.resistance = resistance
        self.effet = effet


class Potion(Item):
    def __init__(self, jeu,  img, type, nom=None, prix=None):
        super().__init__(img, nom, prix)
        self.type = type
        self.utilise = False
        self.jeu = jeu

    def utiliser(self, player):
        if self.type == 'vie' and player.vie < 80:
            player.vie += 20
            self.utilise = True
            player.inventaire['potion'] = None
        elif self.type == 'vitesse':
            self.jeu.chronoVitesse = pg.time.get_ticks()
            player.inventaire['potion'] = None
        elif self.type == 'degat':
            self.jeu.chronoDegat = pg.time.get_ticks()
            player.inventaire['potion'] = None


class Cle(Item):
    def __init__(self, img, nom=None, prix=None):
        super().__init__(img, nom, prix=None)


class Tresor(pg.sprite.Sprite):
    def __init__(self, jeu, img0, img1, type, x, y):
        self.jeu = jeu
        self.groups = jeu.all_sprites, jeu.tresors
        pg.sprite.Sprite.__init__(self, self.groups)
        self.image = img0
        self.img0 = img0
        self.img1 = img1
        self.rect = pg.Rect(x, y, 64, 64)
        self.hitbox = self.rect
        self.type = type
        self.ouvert = False
        self.contenu = {}
        self.affichageEnCours = False

        if self.type == 'Coffre Clé':
            nbOr = randint(25, 50)
            self.contenu['or'] = nbOr
            self.contenu['cle'] = Cle(self.jeu.img_cle, 'Clé de donjon')
        elif self.type == 'Coffre Basique':
            nbOr = randint(50, 125)
            self.contenu['or'] = nbOr
            #nbFleches = randint(3, 10)
            #self.contenu['fleches'] = nbFleches
        elif self.type == 'Coffre Légendaire 1':
            nbOr = randint(150, 250)
            self.contenu['or'] = nbOr
            self.contenu['armure'] = Arme(self.jeu.img_marteau_2, 50, 'marteau', 'Marteau de voyageur', 250)
        elif self.type == 'Coffre Légendaire 2':
            nbOr = randint(250, 500)
            self.contenu['or'] = nbOr
            self.contenu['arme'] = Arme(self.jeu.img_marteau_2, 50, 'marteau', 'Marteau de chevalier', 1400)
        elif self.type == 'Coffre Légendaire 3':
            nbOr = randint(250, 500)
            self.contenu['or'] = nbOr
            self.contenu['armure'] = Armure(self.jeu.img_armure_3, 75, 'Armure légendaire', 1200)
        elif self.type == 'Coffre Légendaire 4':
            nbOr = randint(250, 500)
            self.contenu['or'] = nbOr
            self.contenu['arme'] = Arme(self.jeu.img_marteau_2, 50, 'marteau', 'Marteau légendaire', 1500)
        elif self.type == 'Coffre level2':
            self.contenu['spécial'] = Item(self.jeu.img_saut, 'Saut')
        elif self.type == 'Coffre level3':
            self.contenu['spécial'] = Item(self.jeu.img_bijouxFamille, 'Bijoux de famille')

    def update(self):
        if self.ouvert:
            self.image = self.img1
        else:
            self.image = self.img0

    def afficher_contenu(self):
        self.jeu.ecran.blit(self.jeu.img_fond_coffre, (424, 281))
        self.jeu.draw_text(self.type, self.jeu.font_ecriture, 14, [0, 0, 0], 456, 287)
        for indice, item in self.contenu.items():
            if indice == 'or':
                self.jeu.draw_text('+ '+str(item)+' $', self.jeu.font_ecriture, 13, [255, 255, 255], 436, 318)
            elif indice == 'fleches' and self.jeu.player.fleche < 20:
                self.jeu.draw_text('+ '+str(item), self.jeu.font_ecriture, 13, [255, 255, 255], 436, 342)
            elif indice == 'arme' or indice == 'armure' and not self.jeu.player.inventaire_plein():
                self.jeu.draw_text('+ '+item.nom, self.jeu.font_ecriture, 13, [255, 255, 255], 436, 366)
            elif indice == 'spécial':
                self.jeu.draw_text(item.nom, self.jeu.font_ecriture, 13, [255, 255, 255], 472, 341)
            elif indice == 'cle':
                self.jeu.draw_text('+ ' + item.nom, self.jeu.font_ecriture, 13, [255, 255, 255], 436, 366)

        if self.jeu.mousse_pressed and not self.jeu.clic:
            self.jeu.clic = True
            x, y = pg.mouse.get_pos()
            if 626 < x < 626 + 22 and 281 < y < 281 + 22:
                self.affichageEnCours = False
                self.vider_dans_inventaire(self.jeu.player)
                return 'quitter'

    def vider_dans_inventaire(self, player):
        if not self.ouvert:
            suppr = []
            for indice,item in self.contenu.items():
                if indice == 'or':
                    player.argent += item
                    suppr.append(indice)
                # elif indice == 'fleches' and player.fleche < 20:
                #     player.fleche += item
                #     suppr.append(indice)
                elif indice == 'armure' or indice == 'arme' or indice == 'cle':
                    if not player.inventaire_plein():
                        player.ajouter_dans_inventaire(item)
                        suppr.append(indice)
            for indice in suppr:
                del self.contenu[indice]
            if not self.contenu:
                self.ouvert = True







