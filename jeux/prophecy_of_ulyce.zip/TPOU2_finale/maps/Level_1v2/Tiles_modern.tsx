<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Tiles_modern" tilewidth="64" tileheight="64" tilecount="240" columns="16">
 <image source="Tiles_modern.png" width="1024" height="960"/>
</tileset>
