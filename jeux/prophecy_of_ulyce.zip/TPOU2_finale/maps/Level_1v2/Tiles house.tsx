<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="Tiles_house" tilewidth="64" tileheight="64" tilecount="140" columns="20">
 <image source="Tiles House Roof.png" width="1280" height="468"/>
</tileset>
