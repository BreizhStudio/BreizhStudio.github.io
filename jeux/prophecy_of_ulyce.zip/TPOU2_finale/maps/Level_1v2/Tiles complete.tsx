<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Tiles_complete" tilewidth="64" tileheight="64" tilecount="6642" columns="82">
 <image source="Tileset_complete.png" width="5260" height="5240"/>
</tileset>
