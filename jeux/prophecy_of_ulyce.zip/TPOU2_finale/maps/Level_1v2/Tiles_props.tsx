<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Tiles_or" tilewidth="64" tileheight="64" tilecount="256" columns="16">
 <image source="interieur_1.png" width="1024" height="1024"/>
</tileset>
