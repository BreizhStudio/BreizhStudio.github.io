<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="Tiles" tilewidth="64" tileheight="64" tilecount="200" columns="10">
 <image source="Tiles water grass.png" width="640" height="1280"/>
</tileset>
