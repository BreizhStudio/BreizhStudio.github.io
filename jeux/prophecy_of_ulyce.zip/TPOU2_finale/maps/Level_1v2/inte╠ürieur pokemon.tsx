<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="intérieur pokemon" tilewidth="64" tileheight="64" tilecount="632" columns="8">
 <image source="4g_tileset_interieur.png" width="512" height="5064"/>
</tileset>
