<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="Tiles_indoor1.0" tilewidth="64" tileheight="64" tilecount="225" columns="15">
 <image source="interieur2.png" width="1014" height="1014"/>
</tileset>
